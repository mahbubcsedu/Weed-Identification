﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.Text.RegularExpressions;

namespace weedidapp
{
    public partial class Profile : PhoneApplicationPage
    {
        public Profile()
        {
            InitializeComponent();

            DoHttpWebRequest();
        }

        private void DoHttpWebRequest()
        {
            string GETPROFILE_URI = "http://mpss.csce.uark.edu/~mary/requestprofileexpert.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + App.svusername;

            var request = HttpWebRequest.Create(GETPROFILE_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;

            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                parseProfileTable(contents);
                
                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        private bool parseProfileTable(string tableString)
        {
            const string SERVER_VALID_DATA_HEADER = "SERVER_";
            if (tableString.Trim().Length < SERVER_VALID_DATA_HEADER.Length ||
            !tableString.Trim().Substring(0, SERVER_VALID_DATA_HEADER.Length).Equals(SERVER_VALID_DATA_HEADER)) return false;
            string toParse = tableString.Trim().Substring(SERVER_VALID_DATA_HEADER.Length);

            string[] rows = Regex.Split(toParse, "_ROW_");

            for (int i = 0; i < rows.Length - 1; i++)
            {
                if (rows.Length > i && rows[i].Trim() != "")
                {
                    string[] cols = Regex.Split(rows[i], "_COL_");

                    if (cols.Length == 10)
                    {
                        App.P.expert_id = int.Parse(cols[0]);
                        App.P.first_name = cols[1].Trim();
                        App.P.last_name = cols[2].Trim();
                        App.P.user_name = cols[3].Trim();
                        App.P.fpassword = cols[4].Trim();
                        App.P.location = cols[5].Trim();
                        App.P.ranking = cols[6].Trim();
                        App.P.member_since = cols[7].Trim();
                        App.P.last_activity = cols[8].Trim();

                        Dispatcher.BeginInvoke(() => {
                            usernametxt.Text = App.P.user_name;
                            firstnametxt.Text = App.P.first_name;
                            lastnametxt.Text = App.P.last_name;
                            locationtxt.Text = App.P.location;
                            membersincetxt.Text = App.P.member_since;
                            lastvisitedtxt.Text = App.P.last_activity;
                        });
                    }  
                }
            }
            return true;
        }
        
        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }
}