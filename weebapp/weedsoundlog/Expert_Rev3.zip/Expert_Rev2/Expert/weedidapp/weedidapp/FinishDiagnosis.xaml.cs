﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Threading;
using System.IO.IsolatedStorage;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using System.Windows.Resources;

namespace weedidapp
{
    public partial class FinishDiagnosis : PhoneApplicationPage
    {
        public FinishDiagnosis()
        {
            InitializeComponent();

            diseaseImage.Source = App.weed;

            if (settings["Downloaded"].ToString() == "False")
            {
                settings["Downloaded"] = true;
                dwldprogresstxt.Visibility = Visibility.Visible;
                inc = 0;
                progressBar.Visibility = Visibility.Visible;
                progressBar.Maximum = 55; ;
                percentageText.Visibility = Visibility.Visible;
                WBDoHttpWebRequest();
                downloadingInProgress = true;
                percentageText.Text = "Establishing connection with the server...";
            }
            else
            {
                this.weedsListBox.ItemsSource = (ObservableCollection<DBData>)settings["database"];
                dwldprogresstxt.Visibility = Visibility.Collapsed;
                progressBar.Visibility = Visibility.Collapsed;
                percentageText.Visibility = Visibility.Collapsed;
                //weedsListBox.Items.Add("None of the above");
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (!App.diagnosis.Equals(""))
            {
                selectedDiseaseText.Text = App.diagnosis;
            }
            else
            {
                selectedDiseaseText.Text = "No weed selected.";
            }
            selectedDiseaseImage.Source = App.disease;
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            App.disease = selectedDiseaseImage.Source;
        }

        #region Diagnosis
        bool diagnosisInProgress;
        const string GETWEEDDB_URI = "http://mpss.csce.uark.edu/~ayushs/requestweeddb.php";
        string PhotoFile;
        IsolatedStorageFile isolatedStorageFile;
        IsolatedStorageFileStream isolatedStorageFileStream;
        int k = 0;
        int inc;
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        ObservableCollection<DBData> dataSource;
        bool downloadingInProgress;
        bool photoSize;

        private void btnDiagnose_Click(object sender, RoutedEventArgs e)
        {
            diagnosisInProgress = true;
        }

        private void btnFinishDiagnosis_Click(object sender, RoutedEventArgs e)
        {
            diagnosisInProgress = false;
            this.NavigationService.GoBack();
        }

        private void WBDoHttpWebRequest()
        {
            var request = HttpWebRequest.Create(GETWEEDDB_URI);
            var result = (IAsyncResult)request.BeginGetResponse(WBResponseCallback, request);
        }

        private void WBResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;

            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                WBparseDatabaseTable(contents);

                for (int x = 0; x < App.databaseDataList.Count(); x++)
                {
                    inc++;

                    Dispatcher.BeginInvoke(() => { progressBar.Value = inc; });
                    Dispatcher.BeginInvoke(() => percentageText.Text = ((int)(progressBar.Value * (100.00 / 55.00))).ToString() + " % Complete");

                    getWeedDBPhoto(x);

                    System.Threading.Thread.Sleep(300);
                }

                // TODO: if bool parsed is false need to show error message stating that the database could not be shown.
                createWeedDBList();

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();

                Dispatcher.BeginInvoke(() =>
                {
                    progressBar.Visibility = Visibility.Collapsed;
                    dwldprogresstxt.Visibility = Visibility.Collapsed;
                    percentageText.Visibility = Visibility.Collapsed;
                });
            }
        }

        private bool WBparseDatabaseTable(string tableString)
        {
            const string SERVER_VALID_DATA_HEADER = "SERVER_";
            if (tableString.Trim().Length < SERVER_VALID_DATA_HEADER.Length ||
            !tableString.Trim().Substring(0, SERVER_VALID_DATA_HEADER.Length).Equals(SERVER_VALID_DATA_HEADER)) return false;
            string toParse = tableString.Trim().Substring(SERVER_VALID_DATA_HEADER.Length);

            string[] rows = Regex.Split(toParse, "_ROW_");

            for (int i = 0; i < rows.Length - 1; i++)
            {
                if (rows.Length > i && rows[i].Trim() != "")
                {
                    string[] cols = Regex.Split(rows[i], "_COL_");

                    if (cols.Length == 10)
                    {
                        DatabaseData W = new DatabaseData();
                        W.weedid = int.Parse(cols[0]);
                        W.commonname = cols[1].Trim();
                        W.latinname = cols[2].Trim();
                        W.weedtype = cols[3].Trim();
                        W.lifecycle = cols[4].Trim();
                        W.season = cols[5].Trim();
                        W.site = cols[6].Trim();
                        W.profcontrol = cols[7].Trim();
                        W.homecontrol = cols[8].Trim();

                        App.databaseDataList.Add(W);
                    }
                }
            }

            return true;
        }

        void getWeedDBPhoto(int t)
        {
            string WEEDPHOTO_URI = "http://mpss.csce.uark.edu/~ayushs/weedimages/" + App.databaseDataList[t].weedid + ".jpg";

            PhotoFile = App.databaseDataList[t].weedid + ".jpg";

            WebClient webClient = new WebClient();
            webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(WBwebClient_OpenReadCompleted);
            webClient.OpenReadAsync(new Uri(WEEDPHOTO_URI));
        }

        protected bool WBIncreaseIsolatedStorageSpace(long quotaSizeDemand)
        {
            bool CanSizeIncrease = false;
            IsolatedStorageFile isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();
            //Get the Available space
            long maxAvailableSpace = isolatedStorageFile.AvailableFreeSpace;
            if (quotaSizeDemand > maxAvailableSpace)
            {
                if (!isolatedStorageFile.IncreaseQuotaTo(isolatedStorageFile.Quota + quotaSizeDemand))
                {
                    CanSizeIncrease = false;
                    return CanSizeIncrease;
                }
                CanSizeIncrease = true;
                return CanSizeIncrease;
            }
            return CanSizeIncrease;
        }

        void WBwebClient_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null)
                {
                    #region Isolated Storage Copy Code
                    Dispatcher.BeginInvoke(() =>
                    {
                        isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();

                        bool checkQuotaIncrease = WBIncreaseIsolatedStorageSpace(e.Result.Length);

                        isolatedStorageFileStream = new IsolatedStorageFileStream(PhotoFile, FileMode.Create, isolatedStorageFile);
                        long PhotoFileLength = (long)e.Result.Length;
                        byte[] byteImage = new byte[PhotoFileLength];
                        e.Result.Read(byteImage, 0, byteImage.Length);
                        isolatedStorageFileStream.Write(byteImage, 0, byteImage.Length);

                    #endregion

                        BitmapImage bi = new BitmapImage();
                        bi.SetSource(isolatedStorageFileStream);
                        App.databaseDataList[k++].photoImage = bi;
                        isolatedStorageFileStream.Close();
                    });

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void createWeedDBList()
        {
            Dispatcher.BeginInvoke(() =>
            {
                dataSource = new ObservableCollection<DBData>();

                for (int i = 0; i < App.databaseDataList.Count(); i++)
                {
                    dataSource.Add(new DBData() { ImageSource = App.databaseDataList[i].photoImage, Text = App.databaseDataList[i].commonname, WeedIDNo = App.databaseDataList[i].weedid.ToString() });
                }
                this.weedsListBox.ItemsSource = dataSource;
                settings.Add("database", dataSource);
                downloadingInProgress = false;
            });
        }

        private void weedsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            App.diagnosis = App.databaseDataList[weedsListBox.SelectedIndex].commonname;
            BitmapImage photoImage = new BitmapImage();
            photoImage = App.databaseDataList[weedsListBox.SelectedIndex].photoImage;
            selectedDiseaseImage.Source = photoImage;
            selectedDiseaseText.Text = App.diagnosis;
        }

        #endregion

        private void diseaseImage_Tap(object sender, GestureEventArgs e)
        {
            if (!downloadingInProgress)
            {
                if (!photoSize)
                {
                    photoSize = true;

                    dbboardimage.Visibility = System.Windows.Visibility.Collapsed;
                    weedsListBox.Visibility = System.Windows.Visibility.Collapsed;
                    btnFinishDiagnosis.Visibility = System.Windows.Visibility.Collapsed;
                    selectedDiseaseImage.Visibility = System.Windows.Visibility.Collapsed;
                    selectedDiseaseText.Visibility = System.Windows.Visibility.Collapsed;
                    noWeed.Visibility = System.Windows.Visibility.Collapsed;

                    this.SupportedOrientations = SupportedPageOrientation.PortraitOrLandscape;
                    Thread.Sleep(100);
                    
                    diseaseImage.Width = this.Width;
                    diseaseImage.Height = this.Height;
                    diseaseImage.Margin = new Thickness(0, 0, 0, 0);
                    
                }
                else
                {
                    photoSize = false;
                    this.SupportedOrientations = SupportedPageOrientation.Portrait;
                    Thread.Sleep(100);

                    dbboardimage.Visibility = System.Windows.Visibility.Visible;
                    weedsListBox.Visibility = System.Windows.Visibility.Visible;
                    btnFinishDiagnosis.Visibility = System.Windows.Visibility.Visible;
                    selectedDiseaseImage.Visibility = System.Windows.Visibility.Visible;
                    selectedDiseaseText.Visibility = System.Windows.Visibility.Visible;
                    noWeed.Visibility = System.Windows.Visibility.Visible;

                    diseaseImage.Width = 286;
                    diseaseImage.Height = 219;
                    diseaseImage.Margin = new Thickness(82, 10, 0, 0);
                }
            }
        }

        private void noWeed_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/AddWeed.xaml", UriKind.Relative));
        }
    }
}