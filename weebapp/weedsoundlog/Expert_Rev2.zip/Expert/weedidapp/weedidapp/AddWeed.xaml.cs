﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Threading;
using System.Windows.Navigation;

namespace weedidapp
{
    public partial class AddWeed : PhoneApplicationPage
    {
        private string weedSeason;
        private string weedLifeCycle;
        private string weedCommonName;
        private string control;
        private string notes;

        private bool firstTime = true;

        public AddWeed()
        {
            InitializeComponent();
            rbtnAnnual.IsChecked = true;
            firstTime = false;
        }

        private void sliderSeasonal_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!firstTime)
            {
                switch ((int) sliderSeasonal.Value)
                {
                    case 1:
                        seasonNameTxt.Text = "Spring";
                        break;
                    case 2:
                        seasonNameTxt.Text = "Summer";
                        break;
                    case 3:
                        seasonNameTxt.Text = "Fall";
                        break;
                    case 4:
                        seasonNameTxt.Text = "Winter";
                        break;
                }

                weedSeason = seasonNameTxt.Text;
            }
        }

        private void Annual_Checked(object sender, RoutedEventArgs e)
        {
            weedLifeCycle = "Annual";
        }

        private void Perennial_Checked(object sender, RoutedEventArgs e)
        {
            weedLifeCycle = "Perennial";
        }

        private void GetAllData()
        {
            weedCommonName = commonNameTxt.Text;
            control = controlTxt.Text;
            notes = noteTxt.Text;
        }

        private void addWeed_Click(object sender, RoutedEventArgs e)
        {
            GetAllData();
            this.NavigationService.GoBack();
        }
    }
}