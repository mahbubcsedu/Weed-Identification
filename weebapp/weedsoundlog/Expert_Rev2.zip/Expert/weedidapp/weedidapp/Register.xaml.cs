﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using Microsoft.Phone.Controls.Maps;
using System.Windows.Navigation;
using System.Device.Location;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.GamerServices;

namespace weedidapp
{
    public partial class Register : PhoneApplicationPage
    {
        string username;
        string firstname;
        string lastname;
        string fpassword;
        string location;
        string ranking;
        string membersince;
        string lastvisited;
        bool error;

        public Register()
        {
            InitializeComponent();
            currentLocation.IsChecked = true;
        }

        public void GetRegisterDetails()
        {
            username = usernametxt.Text;
            firstname = firstnametxt.Text;
            lastname = lastnametxt.Text;
            fpassword = passwordtxt.Password;
            //location = locationtxt.Text;
            CheckPasswordLength();
            CheckUserNameLength();
            CheckLocationData();

            // hardcored for now.
            ranking = "1";

            DateTime  datetime = DateTime.Now;
            membersince = datetime.ToString("yyyy-MM-dd");
            lastvisited = datetime.ToString("yyyy-MM-dd HH:mm:ss");  
        }

        public void CheckPasswordLength()
        {
            if (fpassword.Length < 8)
            {
                //ERROR
                MessageBox.Show("Please enter a password which is between 8 and 20 characters in length.");
                error = true;
            }
            else if (fpassword.Length > 20)
            {
                //ERROR
                MessageBox.Show("Please enter a password which is between 8 and 20 characters in length.");
                error = true;
            }
            else 
            {
                error = false;
            }
        }

        public void CheckUserNameLength()
        {
            if (username.Length < 5)
            {
                //ERROR
                MessageBox.Show("Please enter a username which is between 5 and 10 characters in length.");
                error = true;
            }
            else if (username.Length > 10)
            {
                //ERROR
                MessageBox.Show("Please enter a username which is between 5 and 10 characters in length.");
                error = true;
            }
            else
            {
                if (!error)
                {
                    error = false;
                }
            }
        }

        public void CheckLocationData()
        {
            if (!App.latitude.Equals("") || !App.longitude.Equals(""))
            {
                if (!error)
                {
                    error = false;
                }
            }
            else
            {
                error = true;
            }

            //TODO: Check Coordinates
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertexpert.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + username + "&firstname=" + firstname + "&lastname=" + lastname + "&fpassword=" + fpassword + "&location=" + App.latitude + "," + App.longitude + "&ranking=" + ranking + "&membersince=" + membersince + "&lastvisited=" + lastvisited;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                if (contents == "y")
                {
                    App.svusername = username;
                    App.svpassword = fpassword;

                    Dispatcher.BeginInvoke(() =>
                    {
                        this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    });
                }
                else if (contents == "n")
                {
                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    //});

                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    // usernametxt.Text = "";
                    //    passwordtxt.Password = "";

                    //    //loginmsg.Text = "The username or password are incorrect. Please try again.";
                    //    //loginmsg.Visibility = Visibility.Visible;
                    //});
                    MessageBox.Show("Not created!");

                }

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        private void RegisterBtn_Click(object sender, RoutedEventArgs e)
        {
            GetRegisterDetails();
            if (!error)
            {
                DoHttpWebRequest();
                this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
            }

            // Add a check to make sure that the user was actually added. return an echo from the php script

            //this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
        }

        private void radioButton1_Checked(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/RegisterLocation.xaml", UriKind.Relative));
        }

        private void currentLocation_Checked(object sender, RoutedEventArgs e)
        {
            SetUpGPS();
        }

        #region GPS Code
        //Location Data
        GeoCoordinateWatcher watcher;

        private void SetUpGPS()
        {
            if (watcher == null)
            {
                watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);  // using high accuracy 
                watcher.MovementThreshold = 20; // use MovementThreshold to ignore noise in the signal
                watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
                watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            }
            watcher.Start();
        }

        private void CloseGPS()
        {
            if (watcher != null)
            {
                watcher.Stop();
            }
        }

        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    // The Location Service is disabled or unsupported.
                    // Check to see whether the user has disabled the Location Service.
                    if (watcher.Permission == GeoPositionPermission.Denied)
                    {
                        // The user has disabled the Location Service on their device.
                        //textBlock1.Text = "you have this application access to location.";
                        MessageBox.Show("Please enable local services.");

                    }
                    else
                    {
                        //textBlock1.Text = "location is not functioning on this device";
                        MessageBox.Show("Location services are not functioning.");
                    }
                    break;

                case GeoPositionStatus.Initializing:
                    // The Location Service is initializing.
                    // Disable the Start Location button.
                    //SendButton.IsEnabled = false;
                    break;
                case GeoPositionStatus.NoData:
                    // The Location Service is working, but it cannot get location data.
                    // Alert the user and enable the Stop Location button.
                    //textBlock1.Text = "location data is not available.";
                    //SendButton.IsEnabled = true;
                    MessageBox.Show("Location data is not available.");
                    //UploadFileChunk();
                    break;

                case GeoPositionStatus.Ready:
                    break;
            }
        }

        //When the Location Service is ready and receiving data, it will begin to raise the 
        // PositionChanged event and call your application’s handler if you have implemented one. 
        // In the event handler, access the Position member of the GeoPositionChangedEventArgs(Of T) object. 
        // The Position  field is a GeoPosition object, which consists of a Timestamp and a  GeoCoordinate 
        // object that contains the location information for the  reading. This example accesses the latitude and longitude values.

        void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            App.latitude = e.Position.Location.Latitude.ToString("0.0000000");
            App.longitude = e.Position.Location.Longitude.ToString("0.0000000");
        }
        #endregion
    }
}