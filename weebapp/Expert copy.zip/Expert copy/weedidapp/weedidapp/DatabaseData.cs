﻿using System;
using System.Windows.Media.Imaging;


namespace weedidapp
{
    public class DatabaseData
    {
        public int weedid;
        public string commonname;
        public string latinname;
        public string weedtype;
        public string lifecycle;
        public string season;
        public string site;
        public string profcontrol;
        public string homecontrol;
        public BitmapImage photoImage;

        public DatabaseData()
        {
        }   
    }
}