﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.GamerServices;

namespace weedidapp
{
    public partial class Register : PhoneApplicationPage
    {
        string username;
        string firstname;
        string lastname;
        string fpassword;
        string location;
        string ranking;
        string membersince;
        string lastvisited;

        public Register()
        {
            InitializeComponent();
        }

        public void GetRegisterDetails()
        {
            username = usernametxt.Text;
            firstname = firstnametxt.Text;
            lastname = lastnametxt.Text;
            fpassword = passwordtxt.Password;
            location = locationtxt.Text;

            // hardcored for now.
            ranking = "1";

            DateTime  datetime = DateTime.Now;
            membersince = datetime.ToString("yyyy-MM-dd");
            lastvisited = datetime.ToString("yyyy-MM-dd HH:mm:ss");  
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertexpert.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + username + "&firstname=" + firstname + "&lastname=" + lastname + "&fpassword=" + fpassword + "&location=" + location + "&ranking=" + ranking + "&membersince=" + membersince + "&lastvisited=" + lastvisited;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                if (contents == "y")
                {
                    App.svusername = username;
                    App.svpassword = fpassword;

                    Dispatcher.BeginInvoke(() =>
                    {
                        this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    });
                }
                else if (contents == "n")
                {
                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    //});

                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    // usernametxt.Text = "";
                    //    passwordtxt.Password = "";

                    //    //loginmsg.Text = "The username or password are incorrect. Please try again.";
                    //    //loginmsg.Visibility = Visibility.Visible;
                    //});
                    MessageBox.Show("Not created!");

                }

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        private void RegisterBtn_Click(object sender, RoutedEventArgs e)
        {
            GetRegisterDetails();
            DoHttpWebRequest();

            // Add a check to make sure that the user was actually added. return an echo from the php script

            this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
        }
    }
}