﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Threading;
using System.IO.IsolatedStorage;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using System.Windows.Resources;

namespace weedidapp
{
    public partial class RequestInfo : PhoneApplicationPage
    {
        int requstIDNo;

        string diagnosis;
        string idanking;
        string datenow;

        #region Sound Variables
        MemoryStream stream = new MemoryStream();
        private SoundEffectInstance soundInstance;
        bool soundIsPlaying;
        #endregion

        public RequestInfo()
        {
            InitializeComponent();

            displayInfo();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string isChecked;
            if (NavigationContext.QueryString.TryGetValue("requestidno", out isChecked))
            {
                requstIDNo = Convert.ToInt32(isChecked);
                requstIDNo = requstIDNo - 1;
            }
        }

        void displayInfo()
        {
            int? weedid = App.requestsdataList[requstIDNo].weedid;
            // stream = App.requestsdataList[requstIDNo].s
            Dispatcher.BeginInvoke(() =>
            {
                titleRequestIdtxt.Text = "Request ID: " + App.requestsdataList[requstIDNo].identificationid.ToString();

                if (weedid == null)
                {
                    //diagnosistxt.Text = "Not available";
                }
                else
                {
                    int wd = (int)weedid;
                    //diagnosistxt.Text = App.databaseDataList[wd].commonname;
                }

                if ((App.requestsdataList[requstIDNo].idranking.ToString() == "") || (App.requestsdataList[requstIDNo].idranking.ToString() == null))
                {
                    idankingtxt.Text = "Not available";
                }
                else
                {
                    idankingtxt.Text = App.requestsdataList[requstIDNo].idranking.ToString();
                }
                requestsenttxt.Text = App.requestsdataList[requstIDNo].requestsentdate.ToString();

                requestimage.Source = App.requestsdataList[requstIDNo].requestPhotoImage;
            });
        }

        public void GetDetails()
        {
            //diagnosis = diagnosistxt.Text;
            idanking = idankingtxt.Text;
            DateTime datetime = DateTime.Now;
            datenow = datetime.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertdiagnose.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&identificationid=" + App.requestsdataList[requstIDNo].identificationid.ToString() + "&diagnosis=" + diagnosis + "&idanking=" + idanking + "&idsent=" + datenow + "&expertid=" + App.P.expert_id;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
        }

        private void SendBtn_Click(object sender, RoutedEventArgs e)
        {
            GetDetails();
            DoHttpWebRequest();
        }

        #region Play Sound

        private void PlayIcon_Click(object sender, RoutedEventArgs e)
        {
            stream = App.requestsdataList[requstIDNo].stream;
            if (stream != null)
            {
                if (stream.Length > 0)
                {
                    Thread soundThread = new Thread(new ThreadStart(playSound));

                    soundThread.Start();
                }

            }
            else
            {
                MessageBox.Show("No audio to playback.");
            }

        }

        private void playSound()
        {
            SoundEffect sound = new SoundEffect(stream.ToArray(), 16000, AudioChannels.Mono);

            soundInstance = sound.CreateInstance();

            soundIsPlaying = true;

            soundInstance.Play();
        }

        #endregion

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }

        #region Make Image Bigger

        bool photoSize;

        private void requestImage_Tap(object sender, GestureEventArgs e)
        {
            if (!downloadingInProgress)
            {
                if (!photoSize)
                {
                    photoSize = true;
                    if (!diagnosisInProgress)
                    {
                        MakeEverythingNotVisible();
                    }
                    else
                    {
                        dbboardimage.Visibility = System.Windows.Visibility.Collapsed;
                        weedsListBox.Visibility = System.Windows.Visibility.Collapsed;
                        btnFinishDiagnosis.Visibility = System.Windows.Visibility.Collapsed;
                        //requestimage.Margin = new Thickness(80, 20, 0, 0);
                        diagnosebtn.Visibility = System.Windows.Visibility.Collapsed;
                    }

                    this.SupportedOrientations = SupportedPageOrientation.PortraitOrLandscape;
                    Thread.Sleep(100);
                    //Storyboard.SetTargetProperty(moveBox, new PropertyPath(UIEleme
                    requestimage.Width = this.Width;
                    requestimage.Height = this.Height;
                    requestimage.Margin = new Thickness(0, 0, 0, 0);
                    diagnosebtn.Visibility = System.Windows.Visibility.Collapsed;
                }
                else
                {

                    this.SupportedOrientations = SupportedPageOrientation.Portrait;
                    Thread.Sleep(100);
                    if (!diagnosisInProgress)
                    {
                        MakeEverythingVisible();
                        requestimage.Margin = new Thickness(80, 137, 0, 0);
                    }
                    else
                    {
                        MakeWeedDBVisible();
                        requestimage.Margin = new Thickness(80, 20, 0, 0);
                    }
                    photoSize = false;
                    requestimage.Width = 296;
                    requestimage.Height = 210;
                    //requestimage.Margin = new Thickness(80, 137, 0, 0);
                }
            }
        }

        void MakeEverythingNotVisible()
        {
            image1.Visibility = System.Windows.Visibility.Collapsed;
            image2.Visibility = System.Windows.Visibility.Collapsed;
            image3.Visibility = System.Windows.Visibility.Collapsed;
            textBlock2.Visibility = System.Windows.Visibility.Collapsed;
            //textBlock3.Visibility = System.Windows.Visibility.Collapsed;
            textBlock4.Visibility = System.Windows.Visibility.Collapsed;
            //textBlock5.Visibility = System.Windows.Visibility.Collapsed;
            //diagnosistxt.Visibility = System.Windows.Visibility.Collapsed;
            idankingtxt.Visibility = System.Windows.Visibility.Collapsed;
            //idsenttxt.Visibility = System.Windows.Visibility.Collapsed;
            titleRequestIdtxt.Visibility = System.Windows.Visibility.Collapsed;
            playButton.Visibility = System.Windows.Visibility.Collapsed;
            homebtn.Visibility = System.Windows.Visibility.Collapsed;
            diagnosebtn.Visibility = System.Windows.Visibility.Collapsed;
            profilebtn.Visibility = System.Windows.Visibility.Collapsed;
            weeddbbtn.Visibility = System.Windows.Visibility.Collapsed;
            //capturebtn.Visibility = System.Windows.Visibility.Collapsed;
            sendbtn.Visibility = System.Windows.Visibility.Collapsed;
            requestsenttxt.Visibility = System.Windows.Visibility.Collapsed;
            diagnosebtn.Visibility = System.Windows.Visibility.Collapsed;
            btnDiagnose.Visibility = System.Windows.Visibility.Collapsed;
            Diagnosis.Visibility = System.Windows.Visibility.Collapsed;
            //diagnosisText.Visibility = System.Windows.Visibility.Collapsed;
            diagnosisTxt.Visibility = System.Windows.Visibility.Collapsed;
        }

        void MakeEverythingVisible()
        {
            image1.Visibility = System.Windows.Visibility.Visible;
            image2.Visibility = System.Windows.Visibility.Visible;
            image3.Visibility = System.Windows.Visibility.Visible;
            textBlock2.Visibility = System.Windows.Visibility.Visible;
            //textBlock3.Visibility = System.Windows.Visibility.Visible;
            textBlock4.Visibility = System.Windows.Visibility.Visible;
            //textBlock5.Visibility = System.Windows.Visibility.Visible;
            //diagnosistxt.Visibility = System.Windows.Visibility.Visible;
            idankingtxt.Visibility = System.Windows.Visibility.Visible;
            //idsenttxt.Visibility = System.Windows.Visibility.Visible;
            titleRequestIdtxt.Visibility = System.Windows.Visibility.Visible;
            playButton.Visibility = System.Windows.Visibility.Visible;
            homebtn.Visibility = System.Windows.Visibility.Visible;
            diagnosebtn.Visibility = System.Windows.Visibility.Visible;
            profilebtn.Visibility = System.Windows.Visibility.Visible;
            weeddbbtn.Visibility = System.Windows.Visibility.Visible;
            //capturebtn.Visibility = System.Windows.Visibility.Visible;
            sendbtn.Visibility = System.Windows.Visibility.Visible;
            requestsenttxt.Visibility = System.Windows.Visibility.Visible;
            btnDiagnose.Visibility = System.Windows.Visibility.Visible;
            Diagnosis.Visibility = System.Windows.Visibility.Visible;
            //diagnosisText.Visibility = System.Windows.Visibility.Visible;
            diagnosisTxt.Visibility = System.Windows.Visibility.Visible;
        }
        #endregion


        #region Diagnosis
        bool diagnosisInProgress;
        const string GETWEEDDB_URI = "http://mpss.csce.uark.edu/~ayushs/requestweeddb.php";
        string PhotoFile;
        IsolatedStorageFile isolatedStorageFile;
        IsolatedStorageFileStream isolatedStorageFileStream;
        int k = 0;
        int inc;
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        ObservableCollection<DBData> dataSource;
        bool downloadingInProgress;

        private void btnDiagnose_Click(object sender, RoutedEventArgs e)
        {
            MakeEverythingNotVisible();
            MakeWeedDBVisible();
            diagnosisInProgress = true;
        }

        private void btnFinishDiagnosis_Click(object sender, RoutedEventArgs e)
        {
            MakeEverythingVisible();
            MakeWeedDBNotVisible();
            diagnosisInProgress = false;
        }

        private void MakeWeedDBVisible()
        {
            dbboardimage.Visibility = System.Windows.Visibility.Visible;
            weedsListBox.Visibility = System.Windows.Visibility.Visible;
            btnFinishDiagnosis.Visibility = System.Windows.Visibility.Visible;

            requestimage.Margin = new Thickness(80, 20, 0, 0);

            if (settings["Downloaded"].ToString() == "False")
            {
                settings["Downloaded"] = true;
                dwldprogresstxt.Visibility = Visibility.Visible;
                inc = 0;
                progressBar.Visibility = Visibility.Visible;
                progressBar.Maximum = 55; ;
                percentageText.Visibility = Visibility.Visible;
                WBDoHttpWebRequest();
                downloadingInProgress = true;
                percentageText.Text = "Establishing connection with the server...";
            }
            else
            {
                this.weedsListBox.ItemsSource = (ObservableCollection<DBData>)settings["database"];
                dwldprogresstxt.Visibility = Visibility.Collapsed;
                progressBar.Visibility = Visibility.Collapsed;
                percentageText.Visibility = Visibility.Collapsed;
               
                //weedsListBox.Items.Add(enterName);
            }

        }

        private void MakeWeedDBNotVisible()
        {
            dbboardimage.Visibility = System.Windows.Visibility.Collapsed;
            weedsListBox.Visibility = System.Windows.Visibility.Collapsed;
            btnFinishDiagnosis.Visibility = System.Windows.Visibility.Collapsed;
            requestimage.Margin = new Thickness(80, 137, 0, 0);
        }

        private void WBDoHttpWebRequest()
        {
            var request = HttpWebRequest.Create(GETWEEDDB_URI);
            var result = (IAsyncResult)request.BeginGetResponse(WBResponseCallback, request);
        }

        private void WBResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;

            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                WBparseDatabaseTable(contents);

                for (int x = 0; x < App.databaseDataList.Count(); x++)
                {
                    inc++;

                    Dispatcher.BeginInvoke(() => { progressBar.Value = inc; });
                    Dispatcher.BeginInvoke(() => percentageText.Text = ((int)(progressBar.Value * (100.00 / 55.00))).ToString() + " % Complete");

                    getWeedDBPhoto(x);

                    System.Threading.Thread.Sleep(300);
                }

                // TODO: if bool parsed is false need to show error message stating that the database could not be shown.
                createWeedDBList();

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();

                Dispatcher.BeginInvoke(() =>
                {
                    progressBar.Visibility = Visibility.Collapsed;
                    dwldprogresstxt.Visibility = Visibility.Collapsed;
                    percentageText.Visibility = Visibility.Collapsed;
                });
            }
        }

        private bool WBparseDatabaseTable(string tableString)
        {
            const string SERVER_VALID_DATA_HEADER = "SERVER_";
            if (tableString.Trim().Length < SERVER_VALID_DATA_HEADER.Length ||
            !tableString.Trim().Substring(0, SERVER_VALID_DATA_HEADER.Length).Equals(SERVER_VALID_DATA_HEADER)) return false;
            string toParse = tableString.Trim().Substring(SERVER_VALID_DATA_HEADER.Length);

            string[] rows = Regex.Split(toParse, "_ROW_");

            for (int i = 0; i < rows.Length - 1; i++)
            {
                if (rows.Length > i && rows[i].Trim() != "")
                {
                    string[] cols = Regex.Split(rows[i], "_COL_");

                    if (cols.Length == 10)
                    {
                        DatabaseData W = new DatabaseData();
                        W.weedid = int.Parse(cols[0]);
                        W.commonname = cols[1].Trim();
                        W.latinname = cols[2].Trim();
                        W.weedtype = cols[3].Trim();
                        W.lifecycle = cols[4].Trim();
                        W.season = cols[5].Trim();
                        W.site = cols[6].Trim();
                        W.profcontrol = cols[7].Trim();
                        W.homecontrol = cols[8].Trim();

                        App.databaseDataList.Add(W);
                    }
                }
            }

            return true;
        }

        void getWeedDBPhoto(int t)
        {
            string WEEDPHOTO_URI = "http://mpss.csce.uark.edu/~ayushs/weedimages/" + App.databaseDataList[t].weedid + ".jpg";

            PhotoFile = App.databaseDataList[t].weedid + ".jpg";

            WebClient webClient = new WebClient();
            webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(WBwebClient_OpenReadCompleted);
            webClient.OpenReadAsync(new Uri(WEEDPHOTO_URI));
        }

        protected bool WBIncreaseIsolatedStorageSpace(long quotaSizeDemand)
        {
            bool CanSizeIncrease = false;
            IsolatedStorageFile isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();
            //Get the Available space
            long maxAvailableSpace = isolatedStorageFile.AvailableFreeSpace;
            if (quotaSizeDemand > maxAvailableSpace)
            {
                if (!isolatedStorageFile.IncreaseQuotaTo(isolatedStorageFile.Quota + quotaSizeDemand))
                {
                    CanSizeIncrease = false;
                    return CanSizeIncrease;
                }
                CanSizeIncrease = true;
                return CanSizeIncrease;
            }
            return CanSizeIncrease;
        }

        void WBwebClient_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null)
                {
                    #region Isolated Storage Copy Code
                    Dispatcher.BeginInvoke(() =>
                    {
                        isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();

                        bool checkQuotaIncrease = WBIncreaseIsolatedStorageSpace(e.Result.Length);

                        isolatedStorageFileStream = new IsolatedStorageFileStream(PhotoFile, FileMode.Create, isolatedStorageFile);
                        long PhotoFileLength = (long)e.Result.Length;
                        byte[] byteImage = new byte[PhotoFileLength];
                        e.Result.Read(byteImage, 0, byteImage.Length);
                        isolatedStorageFileStream.Write(byteImage, 0, byteImage.Length);

                    #endregion

                        BitmapImage bi = new BitmapImage();
                        bi.SetSource(isolatedStorageFileStream);
                        App.databaseDataList[k++].photoImage = bi;
                        isolatedStorageFileStream.Close();
                        //image1.Source = bi;

                    });

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void createWeedDBList()
        {
            Dispatcher.BeginInvoke(() =>
            {
                dataSource = new ObservableCollection<DBData>();

                for (int i = 0; i < App.databaseDataList.Count(); i++)
                {
                    dataSource.Add(new DBData() { ImageSource = App.databaseDataList[i].photoImage, Text = App.databaseDataList[i].commonname, WeedIDNo = App.databaseDataList[i].weedid.ToString() });
                }
                this.weedsListBox.ItemsSource = dataSource;
                settings.Add("database", dataSource);
                downloadingInProgress = false;
            });
        }


        #endregion

        private void weedsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            diagnosis = App.databaseDataList[weedsListBox.SelectedIndex].commonname;
            //weedsListBox.Items[weedsListBox.SelectedIndex].Text = diagnosis;
            //diagnosisText.Text = diagnosis;
            diagnosisTxt.Text = diagnosis;
        }

        private void diagnosisTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            diagnosis = diagnosisTxt.Text;
            //diagnosisText.Text = diagnosis;
        }
    }
}