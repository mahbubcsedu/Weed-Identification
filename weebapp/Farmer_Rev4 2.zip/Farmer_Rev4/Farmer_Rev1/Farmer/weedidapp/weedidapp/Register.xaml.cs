﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.GamerServices;

namespace weedidapp
{
    public partial class Register : PhoneApplicationPage
    {
        string username;
        string firstname;
        string lastname;
        string fpassword;
        string location;
        string membersince;
        string lastvisited;

        public Register()
        {
            InitializeComponent();
        }

        public void GetRegisterDetails()
        {
            username = usernametxt.Text;
            firstname = firstnametxt.Text;
            lastname = lastnametxt.Text;
            fpassword = passwordtxt.Password;
            location = locationtxt.Text;

            DateTime  datetime = DateTime.Now;
            membersince = datetime.ToString("yyyy-MM-dd");
            lastvisited = datetime.ToString("yyyy-MM-dd HH:mm:ss");  
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertfarmer.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + username + "&firstname=" + firstname + "&lastname=" + lastname + "&fpassword=" + fpassword + "&location=" + location + "&membersince=" + membersince + "&lastvisited=" + lastvisited;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
        }

        private void RegisterBtn_Click(object sender, RoutedEventArgs e)
        {
            GetRegisterDetails();
            DoHttpWebRequest();

            this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
        }
    }
}