﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls.Maps;
using System.Device.Location;


namespace weedidapp
{
    public partial class RegisterLocation : PhoneApplicationPage
    {
        string latitude;
        string longitude;

        Pushpin currentPin = new Pushpin();

        public RegisterLocation()
        {
            InitializeComponent();
            SetUpGPS();
        }

        private void SetUpMap()
        {
            GeoCoordinate mapCenter = new GeoCoordinate(double.Parse(latitude), double.Parse(longitude));
            int zoom = 15;

            // Create a pushpin to put at the center of the view
            //Pushpin pin1 = new Pushpin();
            currentPin.Location = mapCenter;
            currentPin.Content = "Current Location";
            map1.Children.Add(currentPin);

            // Set the map style to Aerial
            map1.Mode = new Microsoft.Phone.Controls.Maps.AerialMode();

            // Set the view and put the map on the page
            map1.SetView(mapCenter, zoom);
        }

        #region GPS Code
        //Location Data
        GeoCoordinateWatcher watcher;

        private void SetUpGPS()
        {
            if (watcher == null)
            {
                watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);  // using high accuracy 
                watcher.MovementThreshold = 20; // use MovementThreshold to ignore noise in the signal
                watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
                watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            }
            watcher.Start();
        }

        private void CloseGPS()
        {
            if (watcher != null)
            {
                watcher.Stop();
            }
        }

        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    // The Location Service is disabled or unsupported.
                    // Check to see whether the user has disabled the Location Service.
                    if (watcher.Permission == GeoPositionPermission.Denied)
                    {
                        // The user has disabled the Location Service on their device.
                        //textBlock1.Text = "you have this application access to location.";
                        MessageBox.Show("Please enable local services.");

                    }
                    else
                    {
                        //textBlock1.Text = "location is not functioning on this device";
                        MessageBox.Show("Location services are not functioning.");
                    }
                    break;

                case GeoPositionStatus.Initializing:
                    // The Location Service is initializing.
                    // Disable the Start Location button.
                    //SendButton.IsEnabled = false;
                    break;
                case GeoPositionStatus.NoData:
                    // The Location Service is working, but it cannot get location data.
                    // Alert the user and enable the Stop Location button.
                    //textBlock1.Text = "location data is not available.";
                    //SendButton.IsEnabled = true;
                    MessageBox.Show("Location data is not available.");
                    //UploadFileChunk();
                    break;

                case GeoPositionStatus.Ready:
                    // The Location Service is working and is receiving location data.
                    // Show the current position and enable the Stop Location button.
                    //textBlock1.Text = "location data is available.";
                    //SendButton.IsEnabled = true;
                    //MessageBox.Show("Latitude: " + latitude + "\nLongitude: " + longitude);
                    SetUpMap();
                    //UploadFileChunk();
                    break;
            }
        }

        //When the Location Service is ready and receiving data, it will begin to raise the 
        // PositionChanged event and call your application’s handler if you have implemented one. 
        // In the event handler, access the Position member of the GeoPositionChangedEventArgs(Of T) object. 
        // The Position  field is a GeoPosition object, which consists of a Timestamp and a  GeoCoordinate 
        // object that contains the location information for the  reading. This example accesses the latitude and longitude values.

        void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            latitude = e.Position.Location.Latitude.ToString("0.0000000");
            longitude = e.Position.Location.Longitude.ToString("0.0000000");
        }
        #endregion

        private void dropPin_Click(object sender, RoutedEventArgs e)
        {
            GeoCoordinate mapCenter = new GeoCoordinate(map1.Center.Latitude, map1.Center.Longitude);
            int zoom = 15;

            // Create a pushpin to put at the center of the view
            //Pushpin pin1 = new Pushpin();
            currentPin.Location = mapCenter;
            currentPin.Content = "Dropped Pin";
            map1.Children.Remove(currentPin);
            map1.Children.Add(currentPin);

            // Set the map style to Aerial
            map1.Mode = new Microsoft.Phone.Controls.Maps.AerialMode();

            // Set the view and put the map on the page
            map1.SetView(mapCenter, zoom);
        }

        private void registerbtn_Click(object sender, RoutedEventArgs e)
        {
            App.latitude = currentPin.Location.Latitude.ToString("0.0000000");
            App.longitude = currentPin.Location.Longitude.ToString("0.0000000");
            //MessageBox.Show("Latitude: " + App.latitude + "Longitude: " + longitude);
            this.NavigationService.GoBack() ;
        }
    }
}