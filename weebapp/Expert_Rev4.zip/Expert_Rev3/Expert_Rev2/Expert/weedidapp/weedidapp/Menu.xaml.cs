﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace weedidapp
{
    public partial class Menu : PhoneApplicationPage
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void WeedDB_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void Diagnose_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void Profile_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }
}