﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using System.Collections.ObjectModel;

namespace weedidapp
{
    public partial class WeedDB : PhoneApplicationPage
    {
        const string GETWEEDDB_URI = "http://mpss.csce.uark.edu/~ayushs/requestweeddb.php";
        string PhotoFile;
        IsolatedStorageFile isolatedStorageFile;
        IsolatedStorageFileStream isolatedStorageFileStream;
        int k = 0;
        int inc;
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        ObservableCollection<DBData> dataSource;

        public WeedDB()
        {
            InitializeComponent();

            //App.databaseDataList.Clear();

            if (settings["Downloaded"].ToString() == "False")
            {
                settings["Downloaded"] = true;
                dwldprogresstxt.Visibility = Visibility.Visible;
                inc = 0;
                progressBar.Visibility = Visibility.Visible;
                progressBar.Maximum = 55; ;
                textBlock2.Visibility = Visibility.Visible;
                DoHttpWebRequest();
                textBlock2.Text = "Establishing connection with the server...";
            }
            else
            {
                this.weedsListBox.ItemsSource = (ObservableCollection<DBData>)settings["database"];
                dwldprogresstxt.Visibility = Visibility.Collapsed;
                progressBar.Visibility = Visibility.Collapsed;
                textBlock2.Visibility = Visibility.Collapsed;
            }
            //settings.Add("Downloaded", true);


        }

        private void DoHttpWebRequest()
        {
            var request = HttpWebRequest.Create(GETWEEDDB_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;

            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                parseDatabaseTable(contents);

                for (int x = 0; x < App.databaseDataList.Count(); x++)
                {
                    inc++;

                    Dispatcher.BeginInvoke(() => { progressBar.Value = inc; });
                    Dispatcher.BeginInvoke(() => textBlock2.Text = ((int)(progressBar.Value * (100.00 / 55.00))).ToString() + " % Complete");

                    getWeedDBPhoto(x);

                    System.Threading.Thread.Sleep(300);
                }

                // TODO: if bool parsed is false need to show error message stating that the database could not be shown.
                createWeedDBList();

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();

                Dispatcher.BeginInvoke(() =>
                {
                    progressBar.Visibility = Visibility.Collapsed;
                    dwldprogresstxt.Visibility = Visibility.Collapsed;
                    textBlock2.Visibility = Visibility.Collapsed;
                });
            }
        }

        private bool parseDatabaseTable(string tableString)
        {
            const string SERVER_VALID_DATA_HEADER = "SERVER_";
            if (tableString.Trim().Length < SERVER_VALID_DATA_HEADER.Length ||
            !tableString.Trim().Substring(0, SERVER_VALID_DATA_HEADER.Length).Equals(SERVER_VALID_DATA_HEADER)) return false;
            string toParse = tableString.Trim().Substring(SERVER_VALID_DATA_HEADER.Length);

            string[] rows = Regex.Split(toParse, "_ROW_");

            for (int i = 0; i < rows.Length - 1; i++)
            {
                if (rows.Length > i && rows[i].Trim() != "")
                {
                    string[] cols = Regex.Split(rows[i], "_COL_");

                    if (cols.Length == 10)
                    {
                        DatabaseData W = new DatabaseData();
                        W.weedid = int.Parse(cols[0]);
                        W.commonname = cols[1].Trim();
                        W.latinname = cols[2].Trim();
                        W.weedtype = cols[3].Trim();
                        W.lifecycle = cols[4].Trim();
                        W.season = cols[5].Trim();
                        W.site = cols[6].Trim();
                        W.profcontrol = cols[7].Trim();
                        W.homecontrol = cols[8].Trim();

                        App.databaseDataList.Add(W);
                    }
                }
            }

            return true;
        }

        void getWeedDBPhoto(int t)
        {
            string WEEDPHOTO_URI = "http://mpss.csce.uark.edu/~ayushs/weedimages/" + App.databaseDataList[t].weedid + ".jpg";

            PhotoFile = App.databaseDataList[t].weedid + ".jpg";

            WebClient webClient = new WebClient();
            webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(webClient_OpenReadCompleted);
            webClient.OpenReadAsync(new Uri(WEEDPHOTO_URI));
        }

        protected bool IncreaseIsolatedStorageSpace(long quotaSizeDemand)
        {
            bool CanSizeIncrease = false;
            IsolatedStorageFile isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();
            //Get the Available space
            long maxAvailableSpace = isolatedStorageFile.AvailableFreeSpace;
            if (quotaSizeDemand > maxAvailableSpace)
            {
                if (!isolatedStorageFile.IncreaseQuotaTo(isolatedStorageFile.Quota + quotaSizeDemand))
                {
                    CanSizeIncrease = false;
                    return CanSizeIncrease;
                }
                CanSizeIncrease = true;
                return CanSizeIncrease;
            }
            return CanSizeIncrease;
        }

        void webClient_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null)
                {
                    #region Isolated Storage Copy Code
                    Dispatcher.BeginInvoke(() =>
                    {
                        isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();

                        bool checkQuotaIncrease = IncreaseIsolatedStorageSpace(e.Result.Length);

                        isolatedStorageFileStream = new IsolatedStorageFileStream(PhotoFile, FileMode.Create, isolatedStorageFile);
                        long PhotoFileLength = (long)e.Result.Length;
                        byte[] byteImage = new byte[PhotoFileLength];
                        e.Result.Read(byteImage, 0, byteImage.Length);
                        isolatedStorageFileStream.Write(byteImage, 0, byteImage.Length);

                    #endregion

                        BitmapImage bi = new BitmapImage();
                        bi.SetSource(isolatedStorageFileStream);
                        App.databaseDataList[k++].photoImage = bi;
                        isolatedStorageFileStream.Close();
                        //image1.Source = bi;

                    });

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void createWeedDBList()
        {
            Dispatcher.BeginInvoke(() =>
            {
                dataSource = new ObservableCollection<DBData>();

                for (int i = 0; i < App.databaseDataList.Count(); i++)
                {
                    dataSource.Add(new DBData() { ImageSource = App.databaseDataList[i].photoImage, Text = App.databaseDataList[i].commonname, WeedIDNo = App.databaseDataList[i].weedid.ToString() });
                }
                this.weedsListBox.ItemsSource = dataSource;
                settings.Add("database", dataSource);
            });
        }

        private void weedinfo_Click(object sender, RoutedEventArgs e)
        {

            string buttonName = (sender as Button).Tag.ToString();
            string page = "/WeedIDInfo.xaml?weedidno=" + buttonName;

            this.NavigationService.Navigate(new Uri(page, UriKind.Relative));

        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
            //Storyboard.SetTarget(5, this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative)));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }

    public class DBData
    {
        public string Text
        {
            get;
            set;
        }

        public BitmapImage ImageSource
        {
            get;
            set;
        }

        public string WeedIDNo
        {
            get;
            set;
        }

    }
}