﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace weedidapp
{
    public partial class RateWeed : PhoneApplicationPage
    {
        public RateWeed()
        {
            InitializeComponent();
        }

        private void idranking_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            App.diagnosisRanking = (int) idranking.Value;
            sliderValue.Text = ((int) idranking.Value).ToString();
        }

        #region Set Notebox Settings
        private void SetNoteBoxBackground()
        {
            //Create a gradient brush for the background
            LinearGradientBrush g = new LinearGradientBrush();
            g.StartPoint = new System.Windows.Point(0.5, 0);    //Start point of the gradient
            g.EndPoint = new System.Windows.Point(0.5, 1);      //End point of the gradient
            GradientStop g1 = new GradientStop();       //Gradient stop 1/2
            g1.Color = System.Windows.Media.Color.FromArgb(255, 193, 171, 141);
            g1.Offset = 0;

            GradientStop g2 = new GradientStop();       //Gradient stop 2/2
            g2.Offset = 1;
            g2.Color = System.Windows.Media.Color.FromArgb(147, 212, 177, 141);

            g.GradientStops.Add(g1);
            g.GradientStops.Add(g2);

            notebox.Background = g;     //Set gradient

            LinearGradientBrush g222 = new LinearGradientBrush();
            g222.StartPoint = new System.Windows.Point(0.5, 0);
            g222.EndPoint = new System.Windows.Point(1, 0.5);
            GradientStop g21 = new GradientStop();
            g21.Color = System.Windows.Media.Colors.Black;
            g21.Offset = 0;

            GradientStop g22 = new GradientStop();
            g22.Offset = 1;
            g22.Color = System.Windows.Media.Color.FromArgb(255, 184, 163, 134);

            g222.GradientStops.Add(g21);
            g222.GradientStops.Add(g22);

            notebox.BorderBrush = g222;
        }

        private void ClearTextBox(object sender, RoutedEventArgs e)
        {
            if (notebox.Text == "Notes:")
            {
                notebox.Text = "";
                SetNoteBoxBackground();
                notebox.FontWeight = FontWeights.Normal;
            }
            SetNoteBoxBackground();
        }

        private void EnterTextBox(object sender, RoutedEventArgs e)
        {
            if (notebox.Text == "")
            {
                notebox.Text = "Notes:";
                SetNoteBoxBackground();
                notebox.FontWeight = FontWeights.Bold;
            }
            SetNoteBoxBackground();
        }
        #endregion
    }
}