﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace weedidapp
{
    public class ProfileData
    {
        public int expert_id;
        public string first_name;
        public string last_name;
        public string user_name;
        public string fpassword;
        public string location;
        public string ranking;
        public string member_since;
        public string last_activity;

        public ProfileData()
        {
        } 
    }
}
