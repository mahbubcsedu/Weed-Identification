﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using Microsoft.Phone.Controls.Maps;
using System.Windows.Navigation;
using System.Device.Location;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.GamerServices;

namespace weedidapp
{
    public partial class Register : PhoneApplicationPage
    {
        string username;
        string firstname;
        string lastname;
        string fpassword;
        string location;
        string ranking;
        string membersince;
        string lastvisited;
        bool error;

        public Register()
        {
            InitializeComponent();
            //currentLocation.IsChecked = true;
        }

        public void GetRegisterDetails()
        {
            username = usernametxt.Text;
            firstname = firstnametxt.Text;
            lastname = lastnametxt.Text;
            fpassword = passwordtxt.Password;
            //location = locationtxt.Text;
            CheckPasswordLength();
            CheckUserNameLength();
            CheckLocationData();

            // hardcored for now.
            ranking = "1";

            DateTime datetime = DateTime.Now;
            membersince = datetime.ToString("yyyy-MM-dd");
            lastvisited = datetime.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public void CheckPasswordLength()
        {
            if (fpassword.Length < 8)
            {
                //ERROR
                MessageBox.Show("Please enter a password which is between 8 and 20 characters in length.");
                error = true;
            }
            else if (fpassword.Length > 20)
            {
                //ERROR
                MessageBox.Show("Please enter a password which is between 8 and 20 characters in length.");
                error = true;
            }
            else
            {
                error = false;
            }
        }

        public void CheckUserNameLength()
        {
            if (username.Length < 5)
            {
                //ERROR
                MessageBox.Show("Please enter a username which is between 5 and 10 characters in length.");
                error = true;
            }
            else if (username.Length > 10)
            {
                //ERROR
                MessageBox.Show("Please enter a username which is between 5 and 10 characters in length.");
                error = true;
            }
            else
            {
                if (!error)
                {
                    error = false;
                }
            }
        }

        public void CheckLocationData()
        {
            if (!App.latitude.Equals("") || !App.longitude.Equals(""))
            {
                if (!error)
                {
                    error = false;
                }
            }
            else
            {
                error = true;
            }

            double latitude;
            double longitude;

            latitude = double.Parse(App.latitude);
            longitude = double.Parse(App.longitude);

            if (latitude > 36.499744 || latitude < 33.004274)
            {
                if (longitude > -89.642214 || longitude < -94.617868)
                {
                    error = true;
                    MessageBox.Show("This service is only available to residents of Arkansas at the current time.");
                }
            }
            //TODO: Check Coordinates
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertfarmer.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + username + "&firstname=" + firstname + "&lastname=" + lastname + "&fpassword=" + fpassword + "&location=" + App.latitude + "," + App.longitude + "&ranking=" + ranking + "&membersince=" + membersince + "&lastvisited=" + lastvisited;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                if (contents == "y")
                {
                    App.svusername = username;
                    App.svpassword = fpassword;

                    Dispatcher.BeginInvoke(() =>
                    {
                        this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    });
                }
                else if (contents == "n")
                {
                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    //});

                    //Dispatcher.BeginInvoke(() =>
                    //{
                    //    // usernametxt.Text = "";
                    //    passwordtxt.Password = "";

                    //    //loginmsg.Text = "The username or password are incorrect. Please try again.";
                    //    //loginmsg.Visibility = Visibility.Visible;
                    //});
                    MessageBox.Show("Not created!");

                }

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        private void RegisterBtn_Click(object sender, RoutedEventArgs e)
        {
            GetRegisterDetails();
            if (!error)
            {
                DoHttpWebRequest();
                this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
            }

            // Add a check to make sure that the user was actually added. return an echo from the php script

            //this.NavigationService.Navigate(new Uri("/Complete.xaml", UriKind.Relative));
        }

        private void mapIt_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/RegisterLocation.xaml", UriKind.Relative));
        }
    }
}