﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using System.Windows.Media.Imaging;
using System.IO.IsolatedStorage;
using System.IO;

namespace weedidapp
{
    public partial class WeedIDInfo : PhoneApplicationPage
    {
        int weedIDNo;

        public WeedIDInfo()
        {
            InitializeComponent();

            displayInfo();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string isChecked;
            if (NavigationContext.QueryString.TryGetValue("weedidno", out isChecked))
            {
                weedIDNo = Convert.ToInt32(isChecked);
                weedIDNo = weedIDNo - 1;
            }
        }

        void displayInfo()
        {
            Dispatcher.BeginInvoke(() =>
            {
                selectedImg.Source = App.databaseDataList[weedIDNo].photoImage;
                commonnametxt.Text = App.databaseDataList[weedIDNo].commonname;
                latinnametxt.Text = App.databaseDataList[weedIDNo].latinname;
                weedtypetxt.Text = App.databaseDataList[weedIDNo].weedtype;
                lifecycletxt.Text = App.databaseDataList[weedIDNo].lifecycle;
                seasontxt.Text = App.databaseDataList[weedIDNo].season;
                sitetxt.Text = App.databaseDataList[weedIDNo].site;

                string text = App.databaseDataList[weedIDNo].profcontrol;
                scrollableTextBlock.Text = text;
            });
        }

        private void ProfBtn_Click(object sender, RoutedEventArgs e)
        {
            controltxt.Text = "Professional Control";
            string text = App.databaseDataList[weedIDNo].profcontrol;
            scrollableTextBlock.Text = text;
        }

        private void HmowBtn_Click(object sender, RoutedEventArgs e)
        {
            controltxt.Text = "Homeowner Control";
            string text = App.databaseDataList[weedIDNo].homecontrol;
            scrollableTextBlock.Text = text;
        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }
}