﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Threading;


namespace weedidapp
{
    public partial class RequestInfo : PhoneApplicationPage
    {
        int requstIDNo;

        #region Sound Variables
        MemoryStream stream = new MemoryStream();
        private SoundEffectInstance soundInstance;
        bool soundIsPlaying;
        #endregion

        public RequestInfo()
        {
            InitializeComponent();

            displayInfo();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string isChecked;
            if (NavigationContext.QueryString.TryGetValue("requestidno", out isChecked))
            {
                requstIDNo = Convert.ToInt32(isChecked);
                requstIDNo = requstIDNo - 1;
            }

            //stream = App.requestsdataList[1].
        }

        void displayInfo()
        {
            int? weedid = App.requestsdataList[requstIDNo].weedid;
           // stream = App.requestsdataList[requstIDNo].s
            Dispatcher.BeginInvoke(() =>
            {
                titleRequestIdtxt.Text = "Request ID: " + App.requestsdataList[requstIDNo].identificationid.ToString();
                
                if (weedid == null)
                {
                    diagnosistxt.Text = "Not available";
                }
                else
                {
                    int wd = (int)weedid;
                    //diagnosistxt.Text = App.databaseDataList[wd].commonname;
                }
                
                if ((App.requestsdataList[requstIDNo].idranking.ToString() == "") || (App.requestsdataList[requstIDNo].idranking.ToString() == null))
                {
                    idankingtxt.Text = "Not available";
                }
                else
                {
                    idankingtxt.Text = App.requestsdataList[requstIDNo].idranking.ToString();
                }
                requestsenttxt.Text = App.requestsdataList[requstIDNo].requestsentdate.ToString();

                if ((App.requestsdataList[requstIDNo].idsentdate == "") || (App.requestsdataList[requstIDNo].idsentdate == null))
                {
                    idsenttxt.Text = "Not available";
                }
                else
                {
                    idsenttxt.Text = App.requestsdataList[requstIDNo].idsentdate.ToString();
                }
                
                requestimage.Source = App.requestsdataList[requstIDNo].requestPhotoImage;
            });
        }

        private void PlayIcon_Click(object sender, RoutedEventArgs e)
        {
            stream = App.requestsdataList[requstIDNo].stream;
            if (stream != null)
            {
                if (stream.Length > 0)
                {
                    Thread soundThread = new Thread(new ThreadStart(playSound));

                    soundThread.Start();
                }
               
            } 
            else
                {
                    MessageBox.Show("No audio to playback.");
                }
          
        }

        private void playSound()
        {
            SoundEffect sound = new SoundEffect(stream.ToArray(), 16000, AudioChannels.Mono);

            soundInstance = sound.CreateInstance();

            soundIsPlaying = true;

            soundInstance.Play();
        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }

        bool photoSize;

        #region Make Image Bigger
        private void requestImage_Tap(object sender, GestureEventArgs e)
        {
            if (!photoSize)
            {
                photoSize = true;
                MakeEverythingNotVisible();

                this.SupportedOrientations = SupportedPageOrientation.PortraitOrLandscape;
                Thread.Sleep(100);
                //Storyboard.SetTargetProperty(moveBox, new PropertyPath(UIEleme
                requestimage.Width = this.Width;
                requestimage.Height = this.Height;
                requestimage.Margin = new Thickness(0, 0, 0, 0);
            }
            else
            {
                
                this.SupportedOrientations = SupportedPageOrientation.Portrait;
                Thread.Sleep(100);
                MakeEverythingVisible();
                photoSize = false;
                requestimage.Width = 296;
                requestimage.Height = 210;
                requestimage.Margin = new Thickness(80, 137, 0, 0);
            }
        }

        void MakeEverythingNotVisible()
        {
            image1.Visibility = System.Windows.Visibility.Collapsed;
            image2.Visibility = System.Windows.Visibility.Collapsed;
            image3.Visibility = System.Windows.Visibility.Collapsed;
            textBlock2.Visibility = System.Windows.Visibility.Collapsed;
            textBlock3.Visibility = System.Windows.Visibility.Collapsed;
            textBlock4.Visibility = System.Windows.Visibility.Collapsed;
            textBlock5.Visibility = System.Windows.Visibility.Collapsed;
            diagnosistxt.Visibility = System.Windows.Visibility.Collapsed;
            idankingtxt.Visibility = System.Windows.Visibility.Collapsed;
            idsenttxt.Visibility = System.Windows.Visibility.Collapsed;
            titleRequestIdtxt.Visibility = System.Windows.Visibility.Collapsed;
            playButton.Visibility = System.Windows.Visibility.Collapsed;
            homebtn.Visibility = System.Windows.Visibility.Collapsed;
            diagnosebtn.Visibility = System.Windows.Visibility.Collapsed;
            profilebtn.Visibility = System.Windows.Visibility.Collapsed;
            weeddbbtn.Visibility = System.Windows.Visibility.Collapsed;
            capturebtn.Visibility = System.Windows.Visibility.Collapsed;
        }

        void MakeEverythingVisible()
        {
            image1.Visibility = System.Windows.Visibility.Visible;
            image2.Visibility = System.Windows.Visibility.Visible;
            image3.Visibility = System.Windows.Visibility.Visible;
            textBlock2.Visibility = System.Windows.Visibility.Visible;
            textBlock3.Visibility = System.Windows.Visibility.Visible;
            textBlock4.Visibility = System.Windows.Visibility.Visible;
            textBlock5.Visibility = System.Windows.Visibility.Visible;
            diagnosistxt.Visibility = System.Windows.Visibility.Visible;
            idankingtxt.Visibility = System.Windows.Visibility.Visible;
            idsenttxt.Visibility = System.Windows.Visibility.Visible;
            titleRequestIdtxt.Visibility = System.Windows.Visibility.Visible;
            playButton.Visibility = System.Windows.Visibility.Visible;
            homebtn.Visibility = System.Windows.Visibility.Visible;
            diagnosebtn.Visibility = System.Windows.Visibility.Visible;
            profilebtn.Visibility = System.Windows.Visibility.Visible;
            weeddbbtn.Visibility = System.Windows.Visibility.Visible;
            capturebtn.Visibility = System.Windows.Visibility.Visible;
        }
        #endregion
    }
}