﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Threading;


namespace weedidapp
{
    public partial class RequestInfo : PhoneApplicationPage
    {
        int requstIDNo;

        #region Sound Variables
        MemoryStream stream = new MemoryStream();
        private SoundEffectInstance soundInstance;
        bool soundIsPlaying;
        #endregion

        public RequestInfo()
        {
            InitializeComponent();

            displayInfo();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string isChecked;
            if (NavigationContext.QueryString.TryGetValue("requestidno", out isChecked))
            {
                requstIDNo = Convert.ToInt32(isChecked);
                requstIDNo = requstIDNo - 1;
            }

            //stream = App.requestsdataList[1].
        }

        void displayInfo()
        {
            string weedid = App.requestsdataList[requstIDNo].weedid;
           // stream = App.requestsdataList[requstIDNo].s
            Dispatcher.BeginInvoke(() =>
            {
                titleRequestIdtxt.Text = "Request ID: " + App.requestsdataList[requstIDNo].identificationid.ToString();
                
                if (weedid == null)
                {
                    diagnosistxt.Text = "Not available";
                }
                else
                {
                    string wd = weedid;
                    diagnosistxt.Text = wd;
                }
                
                if ((App.requestsdataList[requstIDNo].idranking.ToString() == "") || (App.requestsdataList[requstIDNo].idranking.ToString() == null))
                {
                    idankingtxt.Text = "Not available";
                }
                else
                {
                    idankingtxt.Text = App.requestsdataList[requstIDNo].idranking.ToString();
                }
                requestsenttxt.Text = App.requestsdataList[requstIDNo].requestsentdate.ToString();

                if ((App.requestsdataList[requstIDNo].idsentdate == "") || (App.requestsdataList[requstIDNo].idsentdate == null))
                {
                    idsenttxt.Text = "Not available";
                }
                else
                {
                    idsenttxt.Text = App.requestsdataList[requstIDNo].idsentdate.ToString();
                }
                
                requestimage.Source = App.requestsdataList[requstIDNo].requestPhotoImage;
            });
        }

        private void PlayIcon_Click(object sender, RoutedEventArgs e)
        {
            stream = App.requestsdataList[requstIDNo].stream;
            if (stream != null)
            {
                if (stream.Length > 0)
                {
                    Thread soundThread = new Thread(new ThreadStart(playSound));

                    soundThread.Start();
                }
               
            } 
            else
                {
                    MessageBox.Show("No audio to playback.");
                }
          
        }

        private void playSound()
        {
            SoundEffect sound = new SoundEffect(stream.ToArray(), 16000, AudioChannels.Mono);

            soundInstance = sound.CreateInstance();

            soundIsPlaying = true;

            soundInstance.Play();
        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }
}