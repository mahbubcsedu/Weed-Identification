﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Text;
using System.Windows.Threading;

namespace weedidapp
{
    public class RawService
    {
        HttpWebRequest webRequest = null;
        HttpWebResponse webResponse = null;
        Stream responseStream = null;
        public String result;
        public event EventHandler RequestCompleted;
        byte[] data;

        public class RequestState
        {
            // This class stores the State of the request.
            public const int BUFFER_SIZE = 1024;
            public StringBuilder requestData;
            public byte[] BufferRead;

            public RequestState()
            {
                BufferRead = new byte[BUFFER_SIZE];
                requestData = new StringBuilder();
            }
        }


        public RawService()
        {
        }

        public void Abort()
        {
            try
            {
                if (webRequest != null)
                    webRequest.Abort();
                if (webResponse != null)
                    webResponse.Close();
                if (responseStream != null)
                    responseStream.Close();
            }
            catch 
            {
            }
            Deployment.Current.Dispatcher.BeginInvoke(() => { RequestCompleted(this, new EventArgs()); });
        }

        public void Send(String url, byte[] request)
        {
            try
            {
                webRequest = (HttpWebRequest)WebRequest.Create(url);

                webRequest.Method = "POST";

                data = request;

                webRequest.ContentType = "application/binary";

                webRequest.BeginGetRequestStream(new AsyncCallback(GetRequestStreamCallback), new RequestState());

            }
            catch (Exception e)
            {
                result = "Send error: " + e.Message;
                Abort();
            }
        }


        private void GetRequestStreamCallback(IAsyncResult asyncResult)
        {
            try
            {
                RequestState myRequestState = (RequestState)asyncResult.AsyncState;

                // End the operation
                Stream postStream = webRequest.EndGetRequestStream(asyncResult);

                BinaryWriter myWriter = new BinaryWriter(postStream);
                myWriter.Write(data);
                myWriter.Close();

                webRequest.BeginGetResponse(new AsyncCallback(GetResponseCallback), myRequestState);
            }
            catch (Exception e)
            {
                result = "Request error: " + e.Message;
                Abort();
            }

        }

        protected void GetResponseCallback(IAsyncResult asyncResult)
        {
            try
            {
                RequestState myRequestState = (RequestState)asyncResult.AsyncState;
                if (webRequest.HaveResponse == false)
                {
                    throw new Exception("No Response!!!");
                }

                webResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult);

                responseStream = webResponse.GetResponseStream();
                responseStream.BeginRead(myRequestState.BufferRead, 0, RequestState.BUFFER_SIZE, new AsyncCallback(ReadCallBack), myRequestState);
            }
            catch (Exception e)
            {
                result = "Response error: " + e.Message;
                Abort();
            }
        }

        private void ReadCallBack(IAsyncResult asyncResult)
        {
            try
            {

                RequestState myRequestState = (RequestState)asyncResult.AsyncState;
                int read = responseStream.EndRead(asyncResult);
                // Read the HTML page and then do something with it
                if (read > 0)
                {
                    myRequestState.requestData.Append(Encoding.UTF8.GetString(myRequestState.BufferRead, 0, read));
                    IAsyncResult asynchronousResult = responseStream.BeginRead(myRequestState.BufferRead, 0, RequestState.BUFFER_SIZE, new AsyncCallback(ReadCallBack), myRequestState);
                }
                else
                {
                    string stringContent = "";
                    if (myRequestState.requestData.Length > 1)
                    {
                        stringContent = myRequestState.requestData.ToString();
                    }

                    responseStream.Close();
                    responseStream = null;
                    webResponse.Close();
                    webResponse = null;

                    // Parse response
                    result = stringContent;

                    Deployment.Current.Dispatcher.BeginInvoke(() => { RequestCompleted(this, new EventArgs()); });
                }
            }
            catch (Exception e)
            {
                result = "Read error: " + e.Message;
                Abort();
            }
        }

    }
}
