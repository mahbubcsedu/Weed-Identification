﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.Device.Location;
using System.Windows.Media.Imaging;
using System.IO;
using System.IO.IsolatedStorage;
using Microsoft.Phone.Shell;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Devices;
using Microsoft.Phone;
//using System.Windows;
using Microsoft.Phone.BackgroundTransfer;
using Microsoft.Phone.Scheduler;
//using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using System.Windows.Automation;
using System.Windows.Threading;
using System.Threading;

namespace weedidapp
{
    public class RequestsData
    {
        public int identificationid;
        public int weedphotoid;
        public int userid;
        public string weedid;
        public int? expertid;
        public int? idranking;
        public string requestsentdate;
        public string idsentdate;
        public bool? newid;
        public bool newreq;
        public BitmapImage requestPhotoImage;
        public MemoryStream stream;

        public RequestsData()
        {
        }
    }
}