﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using System.Collections.ObjectModel;
using System.Threading;

namespace weedidapp
{
    public partial class Diagnose : PhoneApplicationPage
    {
        string GETREQUEST_URI = "http://mpss.csce.uark.edu/~ayushs/requestdiagnose.php?junk=" + DateTime.Now;
        string PhotoFile, SoundFile;
        IsolatedStorageFile isolatedStorageFile;
        IsolatedStorageFile isolatedStorageSound;
        IsolatedStorageFileStream isolatedStorageFileStream;
        IsolatedStorageFileStream isolatedStorageSoundStream;

        int k;
        int g = -1;
        int inc;

        public Diagnose()
        {
            InitializeComponent();
            App.requestsdataList.Clear();
            dwldprogresstxt.Visibility = Visibility.Visible;
            inc = 0;
            progressBar.Visibility = Visibility.Visible;
            DoHttpWebRequest();
        }

        private void DoHttpWebRequest()
        {
            var request = HttpWebRequest.Create(GETREQUEST_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;

            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                parseRequestTable(contents);

                if (App.requestsdataList.Count() > 0)
                {
                    Dispatcher.BeginInvoke(() => { progressBar.Maximum = App.requestsdataList.Count(); });

                    for (int x = 0; x < App.requestsdataList.Count(); x++)
                    {
                        inc++;
                        Dispatcher.BeginInvoke(() => 
                        { 
                            progressBar.Value = inc;
                            dwldprogresstxt.Text = "Downloading Request\n" + (x + 1) + " of " + App.requestsdataList.Count();
                        });
                        getRequestPhoto(x);
                        getRequestWav(x);
                        System.Threading.Thread.Sleep(300);
                    }

                    // TODO: if bool parsed is false need to show error message stating that the database could not be shown.
                    createRequestList();

                    Dispatcher.BeginInvoke(() => { 
                        progressBar.Visibility = Visibility.Collapsed; 
                        dwldprogresstxt.Visibility = Visibility.Collapsed; 
                    });
                }
                else
                {
                    Dispatcher.BeginInvoke(() => { 
                        dwldprogresstxt.Text = "No requests available.";
                        progressBar.Visibility = Visibility.Collapsed;
                    });
                }

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        private bool parseRequestTable(string tableString)
        {
            const string SERVER_VALID_DATA_HEADER = "SERVER_";
            if (tableString.Trim().Length < SERVER_VALID_DATA_HEADER.Length ||
            !tableString.Trim().Substring(0, SERVER_VALID_DATA_HEADER.Length).Equals(SERVER_VALID_DATA_HEADER)) return false;
            string toParse = tableString.Trim().Substring(SERVER_VALID_DATA_HEADER.Length);

            string[] rows = Regex.Split(toParse, "_ROW_");

            for (int i = 0; i < rows.Length - 1; i++)
            {
                if (rows.Length > i && rows[i].Trim() != "")
                {
                    string[] cols = Regex.Split(rows[i], "_COL_");

                    if (cols.Length == 11)
                    {
                        RequestsData R = new RequestsData();
                       
                        R.identificationid = int.Parse(cols[0]);
                        R.weedphotoid = int.Parse(cols[1]);
                        R.userid = int.Parse(cols[2]);

                        if ((cols[3] == null)||(cols[3] == ""))
                        {
                            R.weedid = null;
                        }
                        else
                        {
                            R.weedid = cols[3];
                        }

                        if ((cols[4] == null)||(cols[4] == ""))
                        {
                            R.expertid = null;
                        }
                        else
                        {
                            R.expertid = int.Parse(cols[4]);
                        }

                        if ((cols[5] == null)||(cols[5] == ""))
                        {
                            R.idranking = null;
                        }
                        else
                        {
                            R.idranking = int.Parse(cols[5]);
                        }

                        R.requestsentdate = cols[6].Trim();

                        if ((cols[7] == null)||(cols[7] == ""))
                        {
                            R.idsentdate = null;
                        }
                        else
                        {
                            R.idsentdate = cols[7].Trim();
                        }

                        bool bvaluereq = (cols[8].Trim() == "1" ? true : false);
                        R.newreq = bvaluereq;
                        bool bvalueid = (cols[9].Trim() == "1" ? true : false);
                        R.newid = bvalueid;                      

                        App.requestsdataList.Add(R);
                       
                   }
                }
            }

            return true;
        }


        void getRequestWav(int t)
        {
            string REQUESTSOUND_URI = "http://mpss.csce.uark.edu/~ayushs/weedsoundlog/sound" + App.requestsdataList[t].weedphotoid + ".wav";

            SoundFile = "Sound" + App.requestsdataList[t].weedphotoid + ".wav";
            g++;
            WebClient webClient = new WebClient();
            webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(webClient_OpenReadCompletedSound);
            webClient.OpenReadAsync(new Uri(REQUESTSOUND_URI));
        }


        void webClient_OpenReadCompletedSound(object sender, OpenReadCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null && e.Result.Length > 0)
                {
                    #region Isolated Storage Copy Code

                    Dispatcher.BeginInvoke(() =>
                    {
                        isolatedStorageSound = IsolatedStorageFile.GetUserStoreForApplication();

                        bool checkQuotaIncrease = IncreaseIsolatedStorageSpace(e.Result.Length);

                        isolatedStorageSoundStream = new IsolatedStorageFileStream(SoundFile, FileMode.Create, isolatedStorageSound);
                        long SoundFileLength = (long)e.Result.Length;
                        byte[] byteSound = new byte[SoundFileLength];
                        e.Result.Read(byteSound, 0, byteSound.Length);
                        isolatedStorageSoundStream.Write(byteSound, 0, byteSound.Length);
                        isolatedStorageSoundStream.Close();

                        MemoryStream soundStream = new MemoryStream(byteSound);
                        App.requestsdataList[g].stream = soundStream;
                        Thread.Sleep(100);
                    });
                    #endregion
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        void getRequestPhoto(int t)
        {
            string REQUESTPHOTO_URI = "http://mpss.csce.uark.edu/~ayushs/weedphotolog/photo" + App.requestsdataList[t].weedphotoid + ".jpg";

            PhotoFile = "photo" + App.requestsdataList[t].weedphotoid + ".jpg";

            WebClient webClient = new WebClient();
            webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(webClient_OpenReadCompleted);
            webClient.OpenReadAsync(new Uri(REQUESTPHOTO_URI));
        }

        protected bool IncreaseIsolatedStorageSpace(long quotaSizeDemand)
        {
            bool CanSizeIncrease = false;
            IsolatedStorageFile isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();
            //Get the Available space
            long maxAvailableSpace = isolatedStorageFile.AvailableFreeSpace;
            if (quotaSizeDemand > maxAvailableSpace)
            {
                if (!isolatedStorageFile.IncreaseQuotaTo(isolatedStorageFile.Quota + quotaSizeDemand))
                {
                    CanSizeIncrease = false;
                    return CanSizeIncrease;
                }
                CanSizeIncrease = true;
                return CanSizeIncrease;
            }
            return CanSizeIncrease;
        }

        void webClient_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            try
            {
                if (e.Result != null && e.Result.Length > 0)
                {
                    #region Isolated Storage Copy Code

                    Dispatcher.BeginInvoke(() =>
                        {
                            isolatedStorageFile = IsolatedStorageFile.GetUserStoreForApplication();

                            bool checkQuotaIncrease = IncreaseIsolatedStorageSpace(e.Result.Length);

                            isolatedStorageFileStream = new IsolatedStorageFileStream(PhotoFile, FileMode.Create, isolatedStorageFile);
                            long PhotoFileLength = (long)e.Result.Length;
                            byte[] byteImage = new byte[PhotoFileLength];
                            e.Result.Read(byteImage, 0, byteImage.Length);
                            isolatedStorageFileStream.Write(byteImage, 0, byteImage.Length);
                            BitmapImage bi = new BitmapImage();
                            bi.SetSource(isolatedStorageFileStream);
                            App.requestsdataList[k++].requestPhotoImage = bi;
                            isolatedStorageFileStream.Close();
                        });
                    #endregion
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void createRequestList()
        {
            string rqcolor = "Black";
 
            Dispatcher.BeginInvoke(() =>
            {
                ObservableCollection<RequestData> dataSource = new ObservableCollection<RequestData>();

                for (int i = 0; i < App.requestsdataList.Count(); i++)
                {
                    if(App.requestsdataList[i].newid == true)
                    {
                        rqcolor = "#FF8AC759";
                    }
                    else if ((App.requestsdataList[i].newreq == true) && (App.requestsdataList[i].newid == false))
                    {
                        rqcolor = "Black";
                    }

                    dataSource.Add(new RequestData() { RequestText = "Request ID: " + App.requestsdataList[i].identificationid.ToString(), RequestIDNo = App.requestsdataList[i].identificationid.ToString(), RequestColor = rqcolor });
                }

                this.weedsListBox.ItemsSource = dataSource;
            });
        }

        private void requestinfo_Click(object sender, RoutedEventArgs e)
        {
            string buttonName = (sender as Button).Tag.ToString();
            string page = "/RequestInfo.xaml?requestidno=" + buttonName;

            this.NavigationService.Navigate(new Uri(page, UriKind.Relative));

        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }

    public class RequestData
    {
        public string RequestText
        {
            get;
            set;
        }

        public string RequestIDNo
        {
            get;
            set;
        }

        public string RequestColor
        {
            get;
            set;
        }
    }
}