﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.IO;

namespace weedidapp
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        
        public MainPage()
        {
            InitializeComponent();
           // if (settings.Count != 2)
           // {
                settings.Clear();
                settings.Add("Downloaded", false);
               // settings.Add("database", 0);
           // }
        }

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {
            //this.NavigationService.Navigate(new Uri("/Login.xaml", UriKind.Relative));
            loginErrors = false;
            CheckForLoginErrors();
            if (!loginErrors)
            {
                GetRegisterDetails();
                DoHttpWebRequest();
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Register.xaml", UriKind.Relative));
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/About.xaml", UriKind.Relative));
        }

        private void userNameGetFocus(object sender, RoutedEventArgs e)
        {
            if (userName.Text == "Username")
            {
                userName.Text = "";
                userName.TextAlignment = TextAlignment.Center;
                userName.Foreground = new SolidColorBrush(Colors.Black);
            }
            userName.Background = null;
            userName.BorderBrush = null;
        }

        private void userNameLoseFocus(object sender, RoutedEventArgs e)
        {
            if (userName.Text == "")
            {
                userName.Text = "Username";
                userName.TextAlignment = TextAlignment.Center;
                userName.Foreground = new SolidColorBrush(Color.FromArgb(255, 23, 108, 19));
            }
            userName.Background = null;
            userName.BorderBrush = null;
        }

        private void passwordBoxGetFocus(object sender, RoutedEventArgs e)
        {
            passwordBox.Background = null;
            passwordBox.BorderBrush = null;
        }

        private void passwordBoxLoseFocus(object sender, RoutedEventArgs e)
        {
            passwordBox.Background = null;
            passwordBox.BorderBrush = null;
        }

        string username;
        string fpassword;


        public void GetRegisterDetails()
        {
            username = userName.Text;
            fpassword = passwordBox.Password;
        }

        private void DoHttpWebRequest()
        {
            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/loginfarmer.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&username=" + username + "&fpassword=" + fpassword;

            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }

        private void ResponseCallback(IAsyncResult result)
        {
            var request = (HttpWebRequest)result.AsyncState;
            var response = request.EndGetResponse(result);

            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                var contents = reader.ReadToEnd();

                if (contents == "y")
                {
                    App.svusername = username;
                    App.svpassword = fpassword;

                    Dispatcher.BeginInvoke(() =>
                    {
                        this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                    });
                }
                else if (contents == "n")
                {
                    Dispatcher.BeginInvoke(() =>
                    {
                        //usernametxt.Text = "";
                        passwordBox.Password = "";

                        MessageBox.Show("The username and/or the password is incorrect. Please try again.");
                        //loginmsg.Visibility = Visibility.Visible;
                    });
                }

                // Clean up the streams.
                if (reader != null) reader.Close();
                if (stream != null) stream.Close();
                if (response != null) response.Close();
            }
        }

        bool loginErrors = false;

        private void CheckForLoginErrors()
        {
            if (userName.Text == "Username" || userName.Text == "")
            {
                MessageBox.Show("Please enter the username!");
                loginErrors = true;
            }

            if (passwordBox.Password == "")
            {
                MessageBox.Show("Please enter the password!");
                loginErrors = true;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/About.xaml", UriKind.Relative));
        }

    }
}