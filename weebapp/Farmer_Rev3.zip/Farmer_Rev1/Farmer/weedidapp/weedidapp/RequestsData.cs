﻿using System;
using System.Windows.Media.Imaging;


namespace weedidapp
{
    public class RequestsData
    {
        public int identificationid;
        public int weedphotoid;
        public int userid;
        public int? weedid;
        public int? expertid;
        public int? idranking;
        public string requestsentdate;
        public string idsentdate;
        public bool? newid;
        public bool newreq;
        public BitmapImage requestPhotoImage;

        public RequestsData()
        {
        }
    }
}