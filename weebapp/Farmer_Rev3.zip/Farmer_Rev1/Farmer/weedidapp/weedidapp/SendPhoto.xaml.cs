﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.Device.Location;
using System.Windows.Media.Imaging;
using System.IO;
using System.IO.IsolatedStorage;
using Microsoft.Phone.Shell;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Devices;
using Microsoft.Phone;
//using System.Windows;
using Microsoft.Phone.BackgroundTransfer;
using Microsoft.Phone.Scheduler;
//using Microsoft.Phone.Controls;
using Microsoft.Xna.Framework;
using System.Windows.Automation;
using System.Windows.Threading;
using System.Threading;


namespace weedidapp
{
    public partial class SendPhoto : PhoneApplicationPage
    {
        // Chunk size of your choosing.
        const int CHUNK_SIZE = 10240;
        BitmapImage bmp;
        const string UPLOAD_URI = @"http://mpss.csce.uark.edu/~ayushs/uploadweedphoto.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&append={0}";
        const string UPLOAD_URISound = @"http://mpss.csce.uark.edu/~ayushs/uploadweedsound.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&append={0}";

        private Stream data = new MemoryStream();                            // Stream to upload
        private long bytesTotal, bytesUploaded;                        // Total bytes to upload

        private const int ResizeWidth_ = 160;
        private const int ResizeHeight_ = 120;
        private const int Quality_ = 50;
        
        // Current upload count.
        RawService service = null;                      // Our raw service class.


        DispatcherTimer tmr = new DispatcherTimer();

        private bool soundIsPlaying = false;
        private SoundEffectInstance soundInstance;              // Used to play back audio

        static readonly Uri uploadServer = new Uri("http://mpss.csce.uark.edu/~ayushs/uploadweedphoto.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&append={0}");
        String g;

        SpaceTime sa = new SpaceTime();

        // Constructor
        public SendPhoto()
        {
            InitializeComponent();

            // Timer to simulate the XNA Game Studio game loop (Microphone is from XNA Game Studio)
            DispatcherTimer dt = new DispatcherTimer();
            dt.Interval = TimeSpan.FromMilliseconds(33);
            dt.Tick += delegate { try { FrameworkDispatcher.Update(); } catch { } };
            dt.Start();

            
            tmr.Interval = TimeSpan.FromMilliseconds(500);
            tmr.Tick += OnTimerTick;

            microphone.BufferReady += new EventHandler<EventArgs>(microphone_BufferReady);        
        }

      

        #region CameraCode

        /// <summary>
        /// Take picture
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        void OnCameraManipulationStarted(object sender, ManipulationStartedEventArgs args)
        {
            
            CameraCaptureTask camera = new CameraCaptureTask();
            
            camera.Show();
            camera.Completed += OnCameraCaptureTaskCompleted;
            args.Complete();
            args.Handled = true;
            base.OnManipulationStarted(args);
            
        }

  




        /// <summary>
        /// Save captured picture to isolated storage.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        /// 

        void OnCameraCaptureTaskCompleted(object sender, PhotoResult args)
        {
            if (args.TaskResult == TaskResult.OK)
            {
                bmp = new BitmapImage();
                bmp.SetSource(args.ChosenPhoto);
                ResizeImage();

                #region Load New Images
                SendButton.Visibility = Visibility.Visible;
                CaptureButton.Visibility = Visibility.Collapsed;
                recordButton.Visibility = Visibility.Visible;
                playButton.Visibility = Visibility.Visible;
                notebox.Visibility = Visibility.Visible;
                rectangle1.Visibility = Visibility.Visible;
                audioInformation.Visibility = Visibility.Visible;
                #endregion
                
            }
        }



        #endregion

        #region Resize Image
        public void ResizeImage()
        {
            WriteableBitmap wbmp;
            wbmp = new WriteableBitmap(bmp);
            wbmp.SaveJpeg(data, ResizeWidth_, ResizeHeight_, 0, Quality_);
            data.Seek(0, SeekOrigin.Begin);
            capimage.Source = wbmp;
        }

        


        private void SendButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            //upload code here.
            
            bytesUploaded = 0;
            bytesTotal = data.Length;
            //MessageBox.Show(bytesTotal.ToString());
            UploadFileChunk();

        }


        private void UploadSoundChunk()
        {
            String uploadUriSound = "";

            if (bytesUploaded == 0)
            {
                uploadUriSound = String.Format(UPLOAD_URISound, 0);
            }
            else if (bytesUploaded < bytesTotal)
            {
                uploadUriSound = String.Format(UPLOAD_URISound, 1);
            }
            else
            {
                return;
            }

            long left = bytesTotal - bytesUploaded;

            if (left > CHUNK_SIZE)
            {
                left = CHUNK_SIZE;
            }

            byte[] fileContent = new byte[left];
            stream.Read(fileContent, 0, (int)left);

            service = new RawService();
            service.RequestCompleted += new EventHandler(wc_RequestCompletedSound);
            service.Send(uploadUriSound, fileContent);

            bytesUploaded += fileContent.Length;
        }

        void wc_RequestCompletedSound(object sender, EventArgs e)
        {
            if (service.result.Substring(0, 2) == "OK")
            {
                service = null;
                if (bytesUploaded < bytesTotal)
                {
                    UploadSoundChunk();
                }
                else
                {
                    DoHttpWebRequest();   
                }
            }
        }

        private void DoHttpWebRequest()
        {
            DateTime datetime = DateTime.Now;
            string datenow = datetime.ToString("yyyy-MM-dd HH:mm:ss");

            string INSERT_URI = "http://mpss.csce.uark.edu/~ayushs/insertphotoinfo.php?code=54m3xuzm97z30rdfsloegjizvzgga12bshptv59o&userid=" + App.P.farmer_id + "&datenow=" + datenow + "&comment="+ notebox.Text;

            //MessageBox.Show(INSERT_URI);
            var request = HttpWebRequest.Create(INSERT_URI);
            var result = (IAsyncResult)request.BeginGetResponse(ResponseCallback, request);
        }


        private void ResponseCallback(IAsyncResult result)
        {
            HttpWebRequest request = result.AsyncState as HttpWebRequest;

            if (request != null)
            {

                using (WebResponse response = request.EndGetResponse(result))
                {

                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {

                        string feed = reader.ReadToEnd();
                        Dispatcher.BeginInvoke(() => { MessageBox.Show("Upload Done");
                        this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
                        });
                    }

                }

            }
        }


        private void UploadFileChunk()
        {
            String uploadUri = "";

            if (bytesUploaded == 0)
            {
                uploadUri = String.Format(UPLOAD_URI, 0);
            }
            else if (bytesUploaded < bytesTotal)
            {
                uploadUri = String.Format(UPLOAD_URI, 1);
            }
            else
            {
                return;
            }

            long left = bytesTotal - bytesUploaded;

            if (left > CHUNK_SIZE)
            {
                left = CHUNK_SIZE;
            }

            byte[] fileContent = new byte[left];
            data.Read(fileContent, 0, (int)left);

            service = new RawService();
            service.RequestCompleted +=new EventHandler(wc_RequestCompleted);
            service.Send(uploadUri, fileContent);

            bytesUploaded += fileContent.Length;

        }


        void wc_RequestCompleted(object sender, EventArgs e)
        {
            if (service.result.Substring(0, 2) == "OK")
            {
                service = null;
                if (bytesUploaded < bytesTotal)
                {
                    UploadFileChunk();
                }
                else
                {
                    bytesUploaded = 0;
                    bytesTotal = stream.Length;
                    stream.Seek(0, SeekOrigin.Begin);
                    //MessageBox.Show(bytesTotal.ToString());
                    UploadSoundChunk();
                }
            }
        }

        #endregion
       
        /// Upload a chunk to service.
        /// 

        #region Old Way of Uploading Things which still works


        /// <summary>
        /// Leaving page.
        /// </summary>
        /// <param name="e"></param>
        /// 
        
        
        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            // When leaving we should close down nicely if we have outstanding stuff.
            if (service != null)
            {
                service.Abort();
                service = null;
            }
            base.OnNavigatedFrom(e);
        }


   

      

       
        #endregion

        /*********************************************************************************************/
        #region Bottom Bar Thingy 
        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }

        #endregion


        #region Microphone Stuff
        //Microphone Variables
        Microphone microphone = Microphone.Default;
        byte[] buffer;
        MemoryStream stream = new MemoryStream();


        void microphone_BufferReady(object sender, EventArgs e)
        {
            microphone.GetData(buffer);
            stream.Write(buffer, 0, buffer.Length);
        }

        bool recording;


        public void WriteWavHeader(Stream stream, int sampleRate)
        {
            const int bitsPerSample = 16;
            const int bytesPerSample = bitsPerSample / 8;
            var encoding = System.Text.Encoding.UTF8;

            // ChunkID Contains the letters "RIFF" in ASCII form (0x52494646 big-endian form).
            stream.Write(encoding.GetBytes("RIFF"), 0, 4);

            // NOTE this will be filled in later
            stream.Write(BitConverter.GetBytes(0), 0, 4);

            // Format Contains the letters "WAVE"(0x57415645 big-endian form).
            stream.Write(encoding.GetBytes("WAVE"), 0, 4);

            // Subchunk1ID Contains the letters "fmt " (0x666d7420 big-endian form).
            stream.Write(encoding.GetBytes("fmt "), 0, 4);

            // Subchunk1Size 16 for PCM.  This is the size of therest of the Subchunk which follows this number.
            stream.Write(BitConverter.GetBytes(16), 0, 4);

            // AudioFormat PCM = 1 (i.e. Linear quantization) Values other than 1 indicate some form of compression.
            stream.Write(BitConverter.GetBytes((short)1), 0, 2);

            // NumChannels Mono = 1, Stereo = 2, etc.
            stream.Write(BitConverter.GetBytes((short)1), 0, 2);

            // SampleRate 8000, 44100, etc.
            stream.Write(BitConverter.GetBytes(sampleRate), 0, 4);

            // ByteRate =  SampleRate * NumChannels * BitsPerSample/8
            stream.Write(BitConverter.GetBytes(sampleRate * bytesPerSample), 0, 4);

            // BlockAlign NumChannels * BitsPerSample/8 The number of bytes for one sample including all channels.
            stream.Write(BitConverter.GetBytes((short)(bytesPerSample)), 0, 2);

            // BitsPerSample    8 bits = 8, 16 bits = 16, etc.
            stream.Write(BitConverter.GetBytes((short)(bitsPerSample)), 0, 2);

            // Subchunk2ID Contains the letters "data" (0x64617461 big-endian form).
            stream.Write(encoding.GetBytes("data"), 0, 4);

            // NOTE to be filled in later
            stream.Write(BitConverter.GetBytes(0), 0, 4);
        }

        public void UpdateWavHeader(Stream stream)
        {
            if (!stream.CanSeek) throw new Exception("Can't seek stream to update wav header");

            var oldPos = stream.Position;

            // ChunkSize  36 + SubChunk2Size
            stream.Seek(4, SeekOrigin.Begin);
            stream.Write(BitConverter.GetBytes((int)stream.Length - 8), 0, 4);

            // Subchunk2Size == NumSamples * NumChannels * BitsPerSample/8 This is the number of bytes in the data.
            stream.Seek(40, SeekOrigin.Begin);
            stream.Write(BitConverter.GetBytes((int)stream.Length - 44), 0, 4);

            stream.Seek(oldPos, SeekOrigin.Begin);
        }
        
        //Record Stuff
        private void recordButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            stream.SetLength(0);
            microphone.BufferDuration = TimeSpan.FromMilliseconds(1000);
            buffer = new byte[microphone.GetSampleSizeInBytes(microphone.BufferDuration)];
            WriteWavHeader(stream, microphone.SampleRate);



            microphone.Start();
            recordButton.Visibility = System.Windows.Visibility.Collapsed;
            stopButton.Visibility = System.Windows.Visibility.Visible;

            recording = true;
            callUpdateRecorder(true);

            timeStampOfAudio.Visibility = System.Windows.Visibility.Visible;
            SendButton.Visibility = System.Windows.Visibility.Collapsed;
        }

        private void callUpdateRecorder(bool recording2)
        {
            if (recording2)
            {
                tmr.Start();
            }
            else
            {
                tmr.Stop();
            }
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            UpdateRecordingTime(recording);
        }
        //Stop the recording
        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            StopRecording();
        }

        //Play the recording again
        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            if (stream.Length > 0)
            {
                Thread soundThread = new Thread(new ThreadStart(playSound));

                soundThread.Start();
            }
            else
            {
                MessageBox.Show("Please record audio");
            }
        }

        private void playSound()
        {

            // Play audio using SoundEffectInstance so we can monitor it's State 

            // and update the UI in the dt_Tick handler when it is done playing.

            SoundEffect sound = new SoundEffect(stream.ToArray(), microphone.SampleRate, AudioChannels.Mono);

            soundInstance = sound.CreateInstance();

            soundIsPlaying = true;

            soundInstance.Play();

        }

        TimeSpan time = new TimeSpan();
        private void UpdateRecordingTime(bool isRecording)
        {
            if (isRecording)
            {
                time = microphone.GetSampleDuration((int)stream.Length);

                if (time.Seconds > 5)
                {
                    StopRecording();
                    UpdateRecordingTime(false);
                    tmr.Stop();
                }
            }
            
            if ((5 - time.Seconds) > 0)
                timeStampOfAudio.Text = (5 - time.Seconds).ToString() + " seconds remaining";
            else
                timeStampOfAudio.Text = "0 second remaining";
              
        }

        private void StopRecording()
        {
            if (microphone.State == MicrophoneState.Started)
            {
                microphone.Stop();
                UpdateRecordingTime(false);
                UpdateWavHeader(stream);
            }

            recording = false;
            recordButton.Visibility = System.Windows.Visibility.Visible;
            stopButton.Visibility = System.Windows.Visibility.Collapsed;

            timeStampOfAudio.Visibility = System.Windows.Visibility.Collapsed;
            SendButton.Visibility = System.Windows.Visibility.Visible;
        }

        #endregion

        #region Set Notebox Settings
        private void SetNoteBoxBackground()
        {
            //Create a gradient brush for the background
            LinearGradientBrush g = new LinearGradientBrush();
            g.StartPoint = new System.Windows.Point(0.5, 0);    //Start point of the gradient
            g.EndPoint = new System.Windows.Point(0.5, 1);      //End point of the gradient
            GradientStop g1 = new GradientStop();       //Gradient stop 1/2
            g1.Color = System.Windows.Media.Color.FromArgb(255, 193, 171, 141);
            g1.Offset = 0;

            GradientStop g2 = new GradientStop();       //Gradient stop 2/2
            g2.Offset = 1;
            g2.Color = System.Windows.Media.Color.FromArgb(147, 212, 177, 141);

            g.GradientStops.Add(g1);
            g.GradientStops.Add(g2);

            notebox.Background = g;     //Set gradient

            LinearGradientBrush g222 = new LinearGradientBrush();
            g222.StartPoint = new System.Windows.Point(0.5, 0);
            g222.EndPoint = new System.Windows.Point(1, 0.5);
            GradientStop g21 = new GradientStop();
            g21.Color = System.Windows.Media.Colors.Black;
            g21.Offset = 0;

            GradientStop g22 = new GradientStop();
            g22.Offset = 1;
            g22.Color = System.Windows.Media.Color.FromArgb(255, 184, 163, 134);

            g222.GradientStops.Add(g21);
            g222.GradientStops.Add(g22);

            notebox.BorderBrush = g222;
        }

        private void ClearTextBox(object sender, RoutedEventArgs e)
        {
            if (notebox.Text == "Notes:")
            {
                notebox.Text = "";
                SetNoteBoxBackground();
                notebox.FontWeight = FontWeights.Normal;
            }
            SetNoteBoxBackground();
        }

        private void EnterTextBox(object sender, RoutedEventArgs e)
        {
            if (notebox.Text == "")
            {
                notebox.Text = "Notes:";
                SetNoteBoxBackground();
                notebox.FontWeight = FontWeights.Bold;
            }
            SetNoteBoxBackground();
        }
        #endregion
    }
}