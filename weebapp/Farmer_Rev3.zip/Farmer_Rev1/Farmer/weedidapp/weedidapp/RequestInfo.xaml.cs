﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Threading;


namespace weedidapp
{
    public partial class RequestInfo : PhoneApplicationPage
    {
        int requstIDNo;

        public RequestInfo()
        {
            InitializeComponent();

            displayInfo();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            string isChecked;
            if (NavigationContext.QueryString.TryGetValue("requestidno", out isChecked))
            {
                requstIDNo = Convert.ToInt32(isChecked);
                requstIDNo = requstIDNo - 1;
            }
        }

        void displayInfo()
        {
            int? weedid = App.requestsdataList[requstIDNo].weedid;
                       
            Dispatcher.BeginInvoke(() =>
            {
                titleRequestIdtxt.Text = "Request ID: " + App.requestsdataList[requstIDNo].identificationid.ToString();
                
                if (weedid == null)
                {
                    diagnosistxt.Text = "Not available";
                }
                else
                {
                    int wd = (int)weedid;
                    //diagnosistxt.Text = App.databaseDataList[wd].commonname;
                }
                
                if ((App.requestsdataList[requstIDNo].idranking.ToString() == "") || (App.requestsdataList[requstIDNo].idranking.ToString() == null))
                {
                    idankingtxt.Text = "Not available";
                }
                else
                {
                    idankingtxt.Text = App.requestsdataList[requstIDNo].idranking.ToString();
                }
                requestsenttxt.Text = App.requestsdataList[requstIDNo].requestsentdate.ToString();

                if ((App.requestsdataList[requstIDNo].idsentdate == "") || (App.requestsdataList[requstIDNo].idsentdate == null))
                {
                    idsenttxt.Text = "Not available";
                }
                else
                {
                    idsenttxt.Text = App.requestsdataList[requstIDNo].idsentdate.ToString();
                }
                
                requestimage.Source = App.requestsdataList[requstIDNo].requestPhotoImage;
            });
        }

        private void PlayIcon_Click(object sender, RoutedEventArgs e)
        {
           
           Thread soundThread = new Thread(new ThreadStart(playSound));
           soundThread.Start();
          
        }

        private void playSound()
        {
        }

        /*********************************************************************************************/

        private void HomeIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Menu.xaml", UriKind.Relative));
        }

        private void WeedDBIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/WeedDB.xaml", UriKind.Relative));
        }

        private void CaptureIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/SendPhoto.xaml", UriKind.Relative));
        }

        private void DiagnoseIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Diagnose.xaml", UriKind.Relative));
        }

        private void ProfileIcon_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Profile.xaml", UriKind.Relative));
        }
    }
}